
/*
 RequireJS order 1.0.5 Copyright (c) 2010-2011, The Dojo Foundation All Rights Reserved.
 Available via the MIT or new BSD license.
 see: http://github.com/jrburke/requirejs for details
*/
(function(){function k(a){var b=a.currentTarget||a.srcElement,c;if(a.type==="load"||l.test(b.readyState)){a=b.getAttribute("data-requiremodule");j[a]=!0;for(a=0;c=g[a];a++)if(j[c.name])c.req([c.name],c.onLoad);else break;a>0&&g.splice(0,a);setTimeout(function(){b.parentNode.removeChild(b)},15)}}function m(a){var b,c;a.setAttribute("data-orderloaded","loaded");for(a=0;c=h[a];a++)if((b=i[c])&&b.getAttribute("data-orderloaded")==="loaded")delete i[c],require.addScriptToDom(b);else break;a>0&&h.splice(0,
a)}var f=typeof document!=="undefined"&&typeof window!=="undefined"&&document.createElement("script"),n=f&&(f.async||window.opera&&Object.prototype.toString.call(window.opera)==="[object Opera]"||"MozAppearance"in document.documentElement.style),o=f&&f.readyState==="uninitialized",l=/^(complete|loaded)$/,g=[],j={},i={},h=[],f=null;define('order',{version:"1.0.5",load:function(a,b,c,e){var d;b.nameToUrl?(d=b.nameToUrl(a,null),require.s.skipAsync[d]=!0,n||e.isBuild?b([a],c):o?(e=require.s.contexts._,!e.urlFetched[d]&&
!e.loaded[a]&&(e.urlFetched[d]=!0,require.resourcesReady(!1),e.scriptCount+=1,d=require.attach(d,e,a,null,null,m),i[a]=d,h.push(a)),b([a],c)):b.specified(a)?b([a],c):(g.push({name:a,req:b,onLoad:c}),require.attach(d,null,a,k,"script/cache"))):b([a],c)}})})();

(function($) {

    var View;
    return kendo.View = (function() {

      // view constructor. takes in the container or selector
      // a template, and the data for the template if any
      function View(container, template, data) {
        // if a container element is specified
        if (container) {
          // if the container is a jquery object
          if (this.container instanceof $) {
            // set the internal reference
            this.container = container 
          }
          // otherwise
          else {
            // set the internal reference to a jQuery instance
            // TODO: should probably check that this is a string
            //       before trying to wrap it
            this.container = $(container);
          }
        }
        // otherwise return an empty div as the container
        else this.container = $("<div></div>");
        
        // set the internal data object to the data passed in,
        // or an empty object if nothing was passed
        this.data = data || {};
        // check to make sure we passed in a template
        // otherwise set it to an empty div
        template = template || "<div></div>";
        // create the kendo template object 
        this.template = kendo.template(template);
        // create an el object that will hold all references to 
        // DOM objects in the view as specified by the "find" method
        this.el = {};
      };

      // renders the template and attaches it to the container. returns
      // a content object which is the template itself as DOM object, 
      // not the container
      View.prototype.render = function(viewModel, bind) {
        // render the kendo template and append it to the container
        this.content = $(this.template(this.data)).appendTo(this.container);
        // if a view model was passed in
        if (viewModel) {
          // set the viewModel variable equal to it
          this.viewModel = viewModel;
            // check if bind was specified. it's not done automatically
            // since mobile views don't bind this way
            if (bind) {
              // bind the container to the view model
              kendo.bind(this.content, this.viewModel);
            }
        }
        // return the template content as a DOM object
        return this.content; 
      };

      // binds the container to the view model
      View.prototype.bind = function(viewModel) {
        this.viewModel = viewModel
        kendo.bind(this.container, this.viewModel)
      };

      // the find method does a simle jQuery find and caches
      // the matched object if a cache string is specified.
      // all cached objects are available off of the el object.
      View.prototype.find = function(selector, cache) {
        // execute the find
        // TODO: Make sure selector is a string
        var match = this.container.find(selector);
        // if a cache is specified
        if (cache) {
          // cache match on the el object by it's specified
          // name
          this.el[cache] = match;
        };
        // return the mached element
        return match;
      };

      View.prototype.destroy = function() {
        this.content.remove();
      }

      return View;

    })();

})(jQuery);
define("libs/kendo/kendo.view", function(){});

(function ($) {
	
	var ui = kendo.mobile.ui,
		Button = ui.Button,
		Widget = ui.Widget,
		support = kendo.support,
        os = support.mobileOS,
        ANDROID3UP = os.android && os.flatVersion >= 300;

	var Clickable = Button.extend({

		init: function (element, options) {

			var that = this;

            Widget.fn.init.call(that, element, options);

            that.element
                .on("up", "_release")
                .on("down", "_activate")
                .on("up cancel", "_deactivate")
                .on("mouseover", "_mouseover")
                .on("mouseout", "_mouseout")

            // add a pointer
            that.element.css("cursor", "pointer")

            if (ANDROID3UP) {
                that.element.on("move", "_timeoutDeactivate");
            }
		},

		options: {
			name: "Clickable"
		},

		_mouseover: function (e) {
			this.trigger("mouseover", { target: e.target });
		},

		_mouseout: function (e) {
			this.trigger("mouseout", { target: e.target });
		}
	});

	// add this new widget to the UI namespace.
	ui.plugin(Clickable);

}(jQuery));
define("libs/kendo/kendo.mobile.clickable", function(){});

// Generated by CoffeeScript 1.4.0
(function() {

  kendo.data.binders.zoom = kendo.data.Binder.extend({
    refresh: function() {
      var value, visible;
      value = this.bindings["zoom"].get();
      visible = $(this.element).is(":visible");
      if (value) {
        if (!visible) {
          $(this.element).kendoStop(true).kendoAnimate({
            effects: "zoomIn fadeIn",
            show: true
          });
        }
      }
      if (!value && visible) {
        return $(this.element).kendoStop(true).kendoAnimate({
          effects: "zoomOut fadeOut",
          show: true
        });
      }
    }
  });

  kendo.data.binders.localeText = kendo.data.Binder.extend({
    refresh: function() {
      var text;
      text = APP.localization[this.bindings.localeText.path];
      if (text == null) {
        console.log("Missing localization for " + this.bindings.localeText.path + ", is it in localization.coffee?");
      }
      return $(this.element).text(text);
    }
  });

  kendo.data.binders.localeHtml = kendo.data.Binder.extend({
    refresh: function() {
      var html;
      html = APP.localization[this.bindings.localeHtml.path];
      if (html == null) {
        console.log("Missing localization for " + this.bindings.localeHtml.path + ", is it in localization.coffee?");
      }
      return $(this.element).html(html);
    }
  });

  kendo.data.binders.localeTitle = kendo.data.Binder.extend({
    refresh: function() {
      var title;
      title = APP.localization[this.bindings.localeTitle.path];
      if (title == null) {
        console.log("Missing localization for " + this.bindings.localeTitle.path + ", is it in localization.coffee?");
      }
      return $(this.element).attr("title", title);
    }
  });

}).call(this);

define("libs/kendo/kendo.custom.binders", function(){});

// Generated by CoffeeScript 1.4.0
(function() {

  define('Kendo',['order!libs/kendo/kendo.view', 'order!libs/kendo/kendo.mobile.clickable', 'order!libs/kendo/kendo.custom.binders'], function() {
    return kendo;
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/utils/utils',[], function() {
    var pub;
    return pub = {
      placeholder: {
        image: function() {
          return "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
        }
      },
      oppositeDirectionOf: function(dir) {
        switch (dir) {
          case "left":
            return "right";
          case "right":
            return "left";
          case "up":
            return "down";
          case "down":
            return "up";
        }
      },
      keys: {
        arrows: {
          up: 38,
          down: 40,
          left: 37,
          right: 39
        },
        esc: 27,
        space: ' '.charCodeAt(0),
        enter: 13,
        w: 'W'.charCodeAt(0),
        page: {
          up: 33,
          down: 34
        }
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/navigation/navigation',[], function() {
    

    var callbacks, pub;
    callbacks = {
      to: {},
      from: {}
    };
    return pub = {
      navigate: function(view) {
        var callback, deferreds, previous, _i, _j, _len, _len1, _ref, _ref1;
        deferreds = [];
        previous = window.APP.app.view().id;
        if (previous in callbacks.from) {
          _ref = callbacks.from[previous];
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            callback = _ref[_i];
            deferreds.push(callback());
          }
        }
        if (view in callbacks.to) {
          _ref1 = callbacks.to[view];
          for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
            callback = _ref1[_j];
            deferreds.push(callback());
          }
        }
        return $.when.apply($, deferreds).done(function() {
          return window.APP.app.navigate(view);
        });
      },
      navigating: {
        to: function(view, callback) {
          if (!(view in callbacks.to)) {
            callbacks.to[view] = [];
          }
          return callbacks.to[view].push(callback);
        },
        from: function(view, callback) {
          if (!(view in callbacks.from)) {
            callbacks.from[view] = [];
          }
          return callbacks.from[view].push(callback);
        }
      }
    };
  });

}).call(this);

/*
 RequireJS text 1.0.6 Copyright (c) 2010-2011, The Dojo Foundation All Rights Reserved.
 Available via the MIT or new BSD license.
 see: http://github.com/jrburke/requirejs for details
*/
(function(){var k=["Msxml2.XMLHTTP","Microsoft.XMLHTTP","Msxml2.XMLHTTP.4.0"],n=/^\s*<\?xml(\s)+version=[\'\"](\d)*.(\d)*[\'\"](\s)*\?>/im,o=/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im,i=typeof location!=="undefined"&&location.href,p=i&&location.protocol&&location.protocol.replace(/\:/,""),q=i&&location.hostname,r=i&&(location.port||void 0),j=[];define('text',[],function(){var g,h,l;typeof window!=="undefined"&&window.navigator&&window.document?h=function(a,c){var b=g.createXhr();b.open("GET",a,!0);b.onreadystatechange=
function(){b.readyState===4&&c(b.responseText)};b.send(null)}:typeof process!=="undefined"&&process.versions&&process.versions.node?(l=require.nodeRequire("fs"),h=function(a,c){var b=l.readFileSync(a,"utf8");b.indexOf("\ufeff")===0&&(b=b.substring(1));c(b)}):typeof Packages!=="undefined"&&(h=function(a,c){var b=new java.io.File(a),e=java.lang.System.getProperty("line.separator"),b=new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(b),"utf-8")),d,f,g="";try{d=new java.lang.StringBuffer;
(f=b.readLine())&&f.length()&&f.charAt(0)===65279&&(f=f.substring(1));for(d.append(f);(f=b.readLine())!==null;)d.append(e),d.append(f);g=String(d.toString())}finally{b.close()}c(g)});return g={version:"1.0.6",strip:function(a){if(a){var a=a.replace(n,""),c=a.match(o);c&&(a=c[1])}else a="";return a},jsEscape:function(a){return a.replace(/(['\\])/g,"\\$1").replace(/[\f]/g,"\\f").replace(/[\b]/g,"\\b").replace(/[\n]/g,"\\n").replace(/[\t]/g,"\\t").replace(/[\r]/g,"\\r")},createXhr:function(){var a,c,
b;if(typeof XMLHttpRequest!=="undefined")return new XMLHttpRequest;else for(c=0;c<3;c++){b=k[c];try{a=new ActiveXObject(b)}catch(e){}if(a){k=[b];break}}if(!a)throw Error("createXhr(): XMLHttpRequest not available");return a},get:h,parseName:function(a){var c=!1,b=a.indexOf("."),e=a.substring(0,b),a=a.substring(b+1,a.length),b=a.indexOf("!");b!==-1&&(c=a.substring(b+1,a.length),c=c==="strip",a=a.substring(0,b));return{moduleName:e,ext:a,strip:c}},xdRegExp:/^((\w+)\:)?\/\/([^\/\\]+)/,useXhr:function(a,
c,b,e){var d=g.xdRegExp.exec(a),f;if(!d)return!0;a=d[2];d=d[3];d=d.split(":");f=d[1];d=d[0];return(!a||a===c)&&(!d||d===b)&&(!f&&!d||f===e)},finishLoad:function(a,c,b,e,d){b=c?g.strip(b):b;d.isBuild&&(j[a]=b);e(b)},load:function(a,c,b,e){if(e.isBuild&&!e.inlineText)b();else{var d=g.parseName(a),f=d.moduleName+"."+d.ext,m=c.toUrl(f),h=e&&e.text&&e.text.useXhr||g.useXhr;!i||h(m,p,q,r)?g.get(m,function(c){g.finishLoad(a,d.strip,c,b,e)}):c([f],function(a){g.finishLoad(d.moduleName+"."+d.ext,d.strip,a,
b,e)})}},write:function(a,c,b){if(c in j){var e=g.jsEscape(j[c]);b.asModule(a+"!"+c,"define(function () { return '"+e+"';});\n")}},writeFile:function(a,c,b,e,d){var c=g.parseName(c),f=c.moduleName+"."+c.ext,h=b.toUrl(c.moduleName+"."+c.ext)+".js";g.load(f,b,function(){var b=function(a){return e(h,a)};b.asModule=function(a,b){return e.asModule(a,h,b)};g.write(a,f,b,d)},d)}}})})();

define('text!mylibs/bar/views/bottom.html',[],function () { return '<section class="bar">\n    <section class="left">\n        <button data-role="button" class="button filters" data-click="APP.bottom.filters" data-bind="visible: filters.visible, localeText: filters_button" data-tabbable tabindex="0"></button>\n        <span class="mode" data-bind="visible: mode.visible">\n            <button data-role="button" data-click="APP.bottom.mode" data-bind="localeTitle: photo" class="selected" data-mode="photo"\n               data-tabbable tabindex="0">\n                <img src="styles/images/singleMode.png">\n            </button>\n            <button data-role="button" data-click="APP.bottom.mode" data-mode="paparazzi" data-bind="localeTitle: paparazzi" data-mode="paparazzi"\n               data-tabbable data-tab-level="0">\n                <img src="styles/images/papparazziMode.png">\n            </button>\n            <!-- <a data-mode="video" class="km-button" data-bind="click: mode.click" data-mode="video" alt="Video" title="Video"><img src="styles/images/videoMode.png"></a> -->\n        </span>\n    </section>\n    <section class="center">\n        <button data-role="button" data-click="APP.bottom.capture" class="km-button capture photo" data-bind="visible: capture.visible" data-tabbable data-tab-level="0">\n            <img src="styles/images/capture.png" class="photo">\n        </button>\n        <div class="countdown">\n            <span class="circle counter">\n                <span class="red-dot"></span>\n            </span>\n            <span class="circle counter">\n                <span class="red-dot"></span>\n            </span>\n            <span class="circle counter">\n                <span class="red-dot"></span>\n            </span>\n        </div>\n        <div class="saving" data-bind="visible: processing.visible">\n            <h3>Processing...</h3>\n        </div>\n    </section>\n    <section class="right">\n        <div class="thumbnail">\n            <div class="absolute" id="destination" class="thumbnail" ></div>\n            <div class="absolute">\n                <a data-role="clickable" data-click="APP.bottom.gallery" data-bind="visible: thumbnail.visible, localeTitle: gallery" class="galleryLink" data-tabbable tabindex="0"></a>\n            </div>\n        <div>\n    </section>\n</section>';});

define('text!mylibs/bar/views/thumbnail.html',[],function () { return '# if (type === \'webm\') { # \n\t<video src="#: file #" class="thumbnail"></video>\n# } else { #\n\t<img src="#: file #" class="thumbnail">\n# } #';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/bar/bottom',['Kendo', 'mylibs/utils/utils', 'mylibs/navigation/navigation', 'text!mylibs/bar/views/bottom.html', 'text!mylibs/bar/views/thumbnail.html'], function(kendo, utils, navigation, template, thumbnailTemplate) {
    var BROKEN_IMAGE, countdown, paused, pub, states, view, viewModel;
    BROKEN_IMAGE = utils.placeholder.image();
    paused = false;
    view = {};
    viewModel = kendo.observable({
      processing: {
        visible: false
      },
      mode: {
        visible: false,
        active: "photo"
      },
      capture: {
        visible: true
      },
      thumbnail: {
        src: BROKEN_IMAGE,
        visible: function() {
          return this.get("enabled") && this.get("active");
        },
        enabled: false,
        active: true
      },
      filters: {
        visible: false,
        open: false,
        css: function() {}
      }
    });
    countdown = function(position, callback) {
      return $("span", view.el.counters[position]).kendoStop(true).kendoAnimate({
        effects: "zoomIn fadeIn",
        duration: 200,
        show: true,
        complete: function() {
          ++position;
          if (position < 3) {
            return setTimeout(function() {
              return countdown(position, callback);
            }, 500);
          } else {
            callback();
            view.el.counters.hide();
            return $("span", view.el.counters).hide();
          }
        }
      });
    };
    states = {
      capture: function() {
        viewModel.set("mode.visible", false);
        viewModel.set("capture.visible", false);
        return viewModel.set("filters.visible", false);
      },
      full: function() {
        viewModel.set("mode.visible", true);
        viewModel.set("capture.visible", true);
        return viewModel.set("filters.visible", true);
      },
      set: function(state) {
        return this[state]();
      }
    };
    return pub = {
      pause: function(pausing) {
        return paused = pausing;
      },
      init: function(container) {
        view = new kendo.View(container, template);
        view.render(viewModel, true);
        view.find(".galleryLink", "galleryLink");
        $.subscribe("/bottom/update", function(state) {
          return states.set(state);
        });
        $.subscribe("/bottom/thumbnail", function(file) {
          var thumbnail;
          view.el.galleryLink.empty();
          if (file) {
            thumbnail = new kendo.View(view.el.galleryLink, thumbnailTemplate, file);
            thumbnail.render();
            return viewModel.set("thumbnail.enabled", true);
          } else {
            return viewModel.set("thumbnail.enabled", false);
          }
        });
        $.subscribe("/keyboard/space", function(e) {
          if (paused) {
            return;
          }
          if (viewModel.get("capture.visible")) {
            return pub.capture(e);
          }
        });
        view.find(".stop", "stop");
        view.find(".counter", "counters");
        view.find(".bar", "bar");
        view.find(".filters", "filters");
        view.find(".capture", "capture");
        return view;
      },
      capture: function(e) {
        var capture, mode;
        mode = viewModel.get("mode.active");
        $.publish("/full/capture/begin", [mode]);
        states.capture();
        capture = function() {
          return $.publish("/capture/" + mode);
        };
        $.publish("/countdown/" + mode);
        if (event.ctrlKey || event.metaKey) {
          return capture();
        } else {
          view.el.counters.css({
            "display": "block"
          });
          return countdown(0, capture);
        }
      },
      filters: function(e) {
        viewModel.set("filters.open", !viewModel.filters.open);
        view.el.filters.toggleClass("selected", viewModel.filters.open);
        return $.publish("/full/filters/show", [viewModel.filters.open]);
      },
      mode: function(e) {
        var button;
        button = $(e.target).closest("button");
        viewModel.set("mode.active", button.data("mode"));
        button.closest(".bar").find("button").removeClass("selected");
        return button.addClass("selected");
      },
      gallery: function() {
        return navigation.navigate("#gallery");
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/file/filewrapper',[], function(file) {
    var asyncFileRequest, pub;
    asyncFileRequest = function(requestMessage, responseMessage, data) {
      var deferred, token;
      deferred = $.Deferred();
      token = $.subscribe(responseMessage, function(result) {
        $.unsubscribe(token);
        return deferred.resolve((result || {}).message);
      });
      $.publish("/postman/deliver", [data, requestMessage, []]);
      return deferred.promise();
    };
    return pub = window.filewrapper = {
      deleteFile: function(filename) {
        return asyncFileRequest("/file/delete", "/file/deleted/" + filename, {
          name: filename
        });
      },
      clear: function() {
        return asyncFileRequest("/file/clear", "/file/cleared", {});
      },
      save: function(filename, blob) {
        return asyncFileRequest("/file/save", "/file/saved/" + filename, {
          name: filename,
          file: blob
        });
      },
      fileListing: function() {
        return asyncFileRequest("/file/listing", "/file/listing/response", {});
      },
      readFile: function(file) {
        return asyncFileRequest("/file/read", "/file/read/" + file.name, {
          file: file.name
        });
      },
      readBulk: function(files) {
        var token;
        token = new Date().getTime();
        return asyncFileRequest("/file/bulk", "/file/bulk/" + token, {
          files: files,
          token: token
        });
      },
      download: function(file) {
        return $.publish("/postman/deliver", [
          {
            name: file.name
          }, "/file/download"
        ]);
      }
    };
  });

}).call(this);

define('text!mylibs/bar/views/galleryBar.html',[],function () { return '<section class="bar">\n    <section class="left">\n        <button data-role="button" data-tabbable tabindex="0" data-click="APP.galleryBar.home" data-bind="invisible: back.details, localeText: back_to_camera_button"></button>\n        <button data-role="button" data-tabbable data-tab-level="0" data-click="APP.galleryBar.back" data-bind="visible: back.details, localeText: back_to_gallery_button" class="back button"></button>\n    </section>\n    <section class="center">\n        <span class="location" data-bind="visible: location.visible, text: location.text"></span>\n    </section>\n    <section class="right">\n        <button data-role="button" data-tabbable tabindex="0" data-click="APP.galleryBar.destroy" data-bind="visible: selected" data-rel="popover" >\n            <img src="styles/images/trashcan.png">\n        </button>\n        <button data-role="button" data-tabbable tabindex="0" data-click="APP.galleryBar.save" data-bind="visible: selected, localeText: save_button" class="kd-button-action"></button>\n    </section>\n</section>\n\n\n';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/bar/galleryBar',['Kendo', 'mylibs/navigation/navigation', 'mylibs/file/filewrapper', 'text!mylibs/bar/views/galleryBar.html'], function(kendo, navigation, filewrapper, template) {
    var pub, states, viewModel,
      _this = this;
    viewModel = kendo.observable({
      current: null,
      selected: false,
      back: {
        details: false,
        text: "< Camera"
      },
      location: {
        visible: false,
        text: ""
      }
    });
    states = {
      selected: function() {
        return viewModel.set("selected", true);
      },
      deselected: function() {
        return viewModel.set("selected", false);
      },
      details: function() {
        viewModel.set("back.text", "< Gallery");
        viewModel.set("back.details", true);
        return $.publish("/gallery/details", [true]);
      },
      gallery: function() {
        viewModel.set("back.text", "< Camera");
        viewModel.set("back.details", false);
        return $.publish("/gallery/details", [false]);
      },
      set: function(state) {
        states.current = state;
        return states[state]();
      }
    };
    return pub = {
      init: function(container) {
        var back, view;
        view = new kendo.View(container, template);
        view.render(viewModel, true);
        back = view.find(".back.button");
        $.subscribe("/galleryBar/update", function(state) {
          return states.set(state);
        });
        $.subscribe("/galleryBar/location", function(message) {
          viewModel.set("location.visible", message.visible);
          return viewModel.set("location.text", message.text);
        });
        $.subscribe("/item/selected", function(message) {
          return viewModel.set("current", message.item);
        });
        return $.subscribe("/keyboard/esc", function() {
          if (states.current === "details") {
            states.set("gallery");
            return back.trigger("click");
          }
        });
      },
      back: function(e) {
        $.publish("/details/hide");
        states.gallery();
        return e.preventDefault();
      },
      destroy: function(e) {
        var view;
        view = viewModel.get("back.details") ? "details" : "gallery";
        $.publish("/" + view + "/keyboard", [false]);
        return $.publish("/confirm/show", [
          window.APP.localization.delete_dialog_title, window.APP.localization.delete_confirmation, function(destroy) {
            $.publish("/" + view + "/keyboard", [true]);
            if (destroy) {
              return $.publish("/gallery/delete");
            }
          }
        ]);
      },
      save: function(e) {
        return filewrapper.download(viewModel.get("current"));
      },
      home: function(e) {
        return navigation.navigate("#home");
      }
    };
  });

}).call(this);

define('text!mylibs/popover/views/popover.html',[],function () { return '<div data-role="popover" id="popover" data-popup=\'{"height": 180, "width": 170}\'>\n    <div data-role="view">\n        <p>The selected image will be deleted.</p>\n\t\t<p><a data-bind="click: ok" class="button"><span>OK</span></a></p>\n\t\t<p><a data-bind="click: cancel" class="cancel button"><span>Cancel</span></a></p>\n    </div>\n</div>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/popover/popover',['Kendo', 'text!mylibs/popover/views/popover.html'], function(kendo, template) {
    var pub, viewModel;
    viewModel = {
      ok: function() {
        $.publish("/gallery/delete");
        return $("#popover").data("kendoMobilePopOver").close();
      },
      cancel: function() {
        return $("#popover").data("kendoMobilePopOver").close();
      }
    };
    return pub = {
      init: function(selector) {
        var view;
        view = new kendo.View(selector, template);
        return view.render(viewModel, true);
      }
    };
  });

}).call(this);

define('text!mylibs/full/views/full.html',[],function () { return '<div class="wrapper">\n    <h1 class="timer hidden"></h1>\n    <img class="snapshot">\n    <div class="filters-list hidden">\n        <ul>\n            # for (var i = 0; i < APP.filters.length; ++i) { #\n                <li data-role="clickable" data-click="APP.full.filter.click" data-bind="events: { mouseover: filter.mouseover, mouseout: filter.mouseout }" data-filter-index="#: i #" data-filter-id="#: APP.filters[i].id #">#: APP.filters[i].name #</li>\n            # } #\n        </ul>\n    </div>\n</div>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/full/full',['Kendo', 'mylibs/utils/utils', 'mylibs/file/filewrapper', 'mylibs/navigation/navigation', 'text!mylibs/full/views/full.html'], function(kendo, utils, filewrapper, navigation, template) {
    var arrow, capture, effectId, elements, frame, full, index, navigating, paparazzi, paused, pub, subscribe, tokens;
    paused = true;
    frame = 0;
    full = {};
    effectId = "";
    paparazzi = {};
    tokens = {};
    capture = function(callback, progress) {
      var captured;
      captured = $.subscribe("/captured/image", function(file) {
        $.unsubscribe(captured);
        $.publish("/gallery/add", [file]);
        return callback();
      });
      return $.publish("/postman/deliver", [progress, "/camera/capture"]);
    };
    index = {
      current: function() {
        var i, _i, _ref;
        for (i = _i = 0, _ref = APP.filters.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
          if (APP.filters[i].id === effectId) {
            return i;
          }
        }
      },
      max: function() {
        return APP.filters.length;
      },
      select: function(i) {
        return pub.select(APP.filters[i]);
      },
      preview: function(i) {
        return pub.select(APP.filters[i], true);
      },
      unpreview: function() {
        return pub.select(APP.filters[index.saved]);
      },
      saved: 0
    };
    arrow = function(dir) {
      if (paused) {
        return;
      }
      if (dir === "up" && index.current() > 0) {
        index.select(index.current() - 1);
      }
      if (dir === "down" && index.current() + 1 < index.max()) {
        return index.select(index.current() + 1);
      }
    };
    subscribe = function(pub) {
      $.subscribe("/full/show", function(item) {
        return pub.show(item);
      });
      $.subscribe("/camera/snapshot", function(url) {
        return full.el.snapshot.attr("src", url);
      });
      $.subscribe("/capture/photo", function() {
        return pub.photo();
      });
      $.subscribe("/capture/paparazzi", function() {
        return pub.paparazzi();
      });
      $.subscribe("/countdown/paparazzi", function() {
        return full.el.paparazzi.removeClass("hidden");
      });
      $.subscribe("/full/filters/show", function(show) {
        var duration;
        duration = 200;
        if (show) {
          tokens.keyboard = $.subscribe("/keyboard/arrow", arrow);
          return full.el.filters.kendoStop().kendoAnimate({
            effects: "slideIn:right fade:in",
            show: true,
            hide: false,
            duration: duration
          });
        } else {
          $.unsubscribe(tokens.keyboard);
          tokens.keyboard = null;
          return full.el.filters.kendoStop().kendoAnimate({
            effects: "slide:left fade:out",
            hide: true,
            show: false,
            duration: duration
          });
        }
      });
      $.subscribe("/full/capture/begin", function(mode) {
        $.publish("/postman/deliver", [mode, "/camera/capture/prepare"]);
        return full.el.wrapper.addClass("capturing");
      });
      return $.subscribe("/full/capture/end", function() {
        return full.el.wrapper.removeClass("capturing");
      });
    };
    elements = {
      cache: function(full) {
        full.find(".timer", "timer");
        full.find(".wrapper", "wrapper");
        full.find(".snapshot", "snapshot");
        full.find(".paparazzi", "paparazzi");
        return full.find(".filters-list", "filters");
      }
    };
    navigating = {
      to: function() {
        var deferred, updated;
        deferred = $.Deferred();
        paused = false;
        APP.bottom.pause(false);
        updated = $.subscribe("/camera/updated", function() {
          var token;
          $.unsubscribe(updated);
          token = $.subscribe("/camera/snapshot/response", function(url) {
            $.unsubscribe(token);
            full.el.snapshot.attr("src", url);
            return deferred.resolve();
          });
          return $.publish("/postman/deliver", [null, "/camera/snapshot/request"]);
        });
        $.publish("/postman/deliver", [null, "/camera/update"]);
        return deferred.promise();
      },
      from: function() {
        var deferred, token;
        deferred = $.Deferred();
        paused = true;
        APP.bottom.pause(true);
        token = $.subscribe("/camera/snapshot/response", function(url) {
          $.unsubscribe(token);
          full.el.snapshot.attr("src", url);
          return deferred.resolve();
        });
        $.publish("/postman/deliver", [null, "/camera/snapshot/request"]);
        return deferred.promise();
      }
    };
    return pub = {
      init: function(selector) {
        full = new kendo.View(selector, template);
        full.render();
        navigation.navigating.to("#home", navigating.to);
        navigation.navigating.from("#home", navigating.from);
        elements.cache(full);
        return subscribe(pub);
      },
      before: function() {
        return setTimeout((function() {
          return $.publish("/postman/deliver", [
            {
              paused: false
            }, "/camera/pause"
          ]);
        }), 500);
      },
      show: function(item) {
        if (!paused) {
          return;
        }
        pub.select(item);
        paused = false;
        return full.container.kendoStop(true).kendoAnimate({
          effects: "zoomIn fadeIn",
          show: true,
          complete: function() {
            return $.publish("/bottom/update", ["full"]);
          }
        });
      },
      select: function(item, temp) {
        effectId = item.id;
        if (!temp) {
          full.el.filters.find("li").removeClass("selected").filter("[data-filter-id=" + item.id + "]").addClass("selected");
        }
        return $.publish("/postman/deliver", [effectId, "/camera/effect"]);
      },
      filter: {
        click: function(e) {
          var i;
          i = $(e.target).data("filter-index");
          index.saved = i;
          return index.select(i);
        },
        mouseover: function(e) {
          return index.preview($(e.target).data("filter-index"));
        },
        mouseout: function(e) {
          return index.unpreview();
        }
      },
      photo: function() {
        var callback;
        callback = function() {
          $.publish("/bottom/update", ["full"]);
          return $.publish("/full/capture/end");
        };
        return capture(callback, {
          index: 0,
          count: 1
        });
      },
      paparazzi: function() {
        var callback;
        callback = function() {
          callback = function() {
            callback = function() {
              $.publish("/bottom/update", ["full"]);
              return $.publish("/full/capture/end");
            };
            return setTimeout((function() {
              return capture(callback, {
                index: 2,
                count: 3
              });
            }), 1000);
          };
          return setTimeout((function() {
            return capture(callback, {
              index: 1,
              count: 3
            });
          }), 1000);
        };
        return capture(callback, {
          index: 0,
          count: 3
        });
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/postman/postman',[], function() {
    /*		The Postman!
    
    	The postman is a super simple combination of pub/sub and post message.
    
    	outgoing: the postman simply listens for the /postman/deliver message and dispatches whatever
    	its contents are as the body of the 'message' object. The address is used by the receiver
    	to determine who should respond to the message.
    
    	incoming: the postman listens to the post message event on the window and
    	dispatches the event with the address specified
    */

    var pub;
    return pub = {
      init: function(r) {
        var recipient;
        recipient = r;
        window.onmessage = function(event) {
          return $.publish(event.data.address, [event.data.message]);
        };
        return $.subscribe("/postman/deliver", function(message, address, block) {
          var delivery;
          delivery = {};
          delivery.address = address;
          delivery.message = message;
          return recipient.postMessage(delivery, "*", block);
        });
      }
    };
  });

}).call(this);

define('text!mylibs/gallery/views/thumb.html',[],function () { return '<div class="thumbnail"></div>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/gallery/gallery',['Kendo', 'mylibs/utils/utils', 'mylibs/file/filewrapper', 'text!mylibs/gallery/views/thumb.html'], function(kendo, utils, filewrapper, template) {
    var active, add, animation, arrows, at, clear, columns, container, create, data, dataSource, deselect, destroy, details, ds, el, files, flipping, get, index, keyboard, keys, page, pageSize, pages, pub, render, rows, select, selected, total, updateLocation,
      _this = this;
    columns = 3;
    rows = 3;
    pageSize = columns * rows;
    files = [];
    ds = {};
    data = [];
    container = {};
    el = {};
    selected = {};
    total = 0;
    index = 0;
    flipping = false;
    pages = {
      previous: {},
      next: {}
    };
    active = {};
    details = false;
    keyboard = {};
    animation = {
      effects: "pageturn:horizontal",
      reverse: false,
      duration: 800
    };
    deselect = function() {
      container.find(".thumbnail").removeClass("selected");
      selected = null;
      return $.publish("/galleryBar/update", ["deselected"]);
    };
    select = function(name) {
      var item;
      item = container.find("[data-name='" + name + "']");
      selected = item.parent(":first");
      if (selected.hasClass("selected")) {
        keys.unbind();
        return $.publish("/details/show", [get("" + (item.data("name")))]);
      } else {
        container.find(".thumbnail").removeClass("selected").removeAttr("tabindex");
        selected.addClass("selected");
        selected.attr("tabindex", 0);
        selected.focus();
        $.publish("/item/selected", [get(name)]);
        return $.publish("/galleryBar/update", ["selected"]);
      }
    };
    page = function(direction) {
      if (flipping) {
        return;
      }
      arrows.both.hide();
      if (direction > 0 && ds.page() > 1) {
        flipping = true;
        animation.reverse = true;
        ds.page(ds.page() - 1);
        render(true);
      }
      if (direction < 0 && ds.page() < ds.totalPages()) {
        flipping = true;
        animation.reverse = false;
        ds.page(ds.page() + 1);
        return render(true);
      }
    };
    clear = function() {
      pages.previous.empty();
      pages.next.empty();
      return $.publish("/postman/deliver", [{}, "/file/read"]);
    };
    destroy = function() {
      var name,
        _this = this;
      name = selected.children(":first").attr("data-name");
      return selected.kendoStop(true).kendoAnimate({
        effects: "zoomOut fadeOut",
        hide: true,
        complete: function() {
          return filewrapper.deleteFile(name).done(function() {
            $.publish("/galleryBar/update", ["deselected"]);
            selected.remove();
            ds.remove(ds.get(name));
            return render();
          });
        }
      });
    };
    updateLocation = function() {
      if (!details) {
        return $.publish("/galleryBar/location", [
          {
            visible: true,
            text: "Page " + (ds.page()) + " of " + (ds.totalPages())
          }
        ]);
      }
    };
    get = function(name) {
      var match, position;
      match = ds.get(name);
      index = ds.view().indexOf(match);
      position = ds.page() > 1 ? pageSize * (ds.page() - 1) + index : index;
      return {
        length: ds.data().length,
        index: position,
        item: match
      };
    };
    at = function(newIndex, noPage) {
      var match, position, target;
      index = newIndex;
      target = Math.ceil((index + 1) / pageSize);
      if (target !== ds.page()) {
        if (!noPage) {
          ds.page(target);
          render();
        }
      }
      position = index - pageSize * (target - 1);
      match = {
        length: ds.data().length,
        index: index,
        item: ds.view()[position]
      };
      $.publish("/details/update", [match]);
      return select(match.item.name);
    };
    dataSource = {
      create: function(data) {
        return ds = new kendo.data.DataSource({
          data: data,
          pageSize: pageSize,
          change: function() {
            return deselect();
          },
          sort: {
            dir: "desc",
            field: "name"
          },
          schema: {
            model: {
              id: "name"
            }
          }
        });
      }
    };
    add = function(item) {
      item = {
        name: item.name,
        type: item.type
      };
      if (!ds) {
        return ds = dataSource.create([item]);
      } else {
        return ds.add(item);
      }
    };
    create = function(item) {
      var element, fadeIn;
      element = {};
      fadeIn = function(e) {
        return $(e).kendoAnimate({
          effects: "fadeIn",
          show: true
        });
      };
      element = new Image();
      element.onload = fadeIn(element);
      element.src = item.file;
      element.setAttribute("data-name", item.name);
      element.setAttribute("draggable", true);
      element.width = 240;
      element.height = 180;
      element.setAttribute("class", "hidden");
      $(element).on("focus", function(e) {
        return $(e.target).parent().addClass("selected");
      });
      $(element).kendoMobileClickable({
        click: pub.click
      });
      return element;
    };
    render = function(flip) {
      var file, _i, _len, _ref;
      files = [];
      _ref = ds.view();
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        file = _ref[_i];
        files.push(file.name);
      }
      return filewrapper.readBulk(files).done(function(message) {
        var compare, complete, item, thumbnail, thumbs, _j, _len1;
        compare = function(a, b) {
          if (a.name > b.name) {
            return -1;
          }
          if (a.name < b.name) {
            return 1;
          }
          return 0;
        };
        message.sort(compare);
        thumbs = [];
        for (_j = 0, _len1 = message.length; _j < _len1; _j++) {
          item = message[_j];
          thumbnail = new kendo.View(pages.next, template);
          thumbs.push({
            dom: thumbnail.render({}, true),
            data: item
          });
        }
        $("#gallery").css("pointer-events", "none");
        complete = function() {
          var justPaged;
          setTimeout(function() {
            var first, _fn, _k, _len2;
            _fn = function() {
              var element;
              element = create(item.data);
              return item.dom.append(element);
            };
            for (_k = 0, _len2 = thumbs.length; _k < _len2; _k++) {
              item = thumbs[_k];
              _fn();
            }
            first = thumbs[0].dom;
            first.attr("tabindex", 0);
            return first.attr("data-tabbable", "");
          }, 50);
          pages.next.show();
          justPaged = pages.previous;
          justPaged.hide();
          justPaged.empty();
          pages.previous = pages.next;
          pages.next = justPaged;
          flipping = false;
          arrows.left.toggle(ds.page() > 1);
          arrows.right.toggle(ds.page() < ds.totalPages());
          updateLocation();
          $("#gallery").css("pointer-events", "auto");
          return setTimeout(function() {
            return at((ds.page() - 1) * pageSize);
          }, 50);
        };
        if (flip) {
          return container.kendoAnimate({
            effects: animation.effects,
            face: animation.reverse ? pages.next : pages.previous,
            back: animation.reverse ? pages.previous : pages.next,
            duration: animation.duration,
            reverse: animation.reverse,
            complete: complete
          });
        } else {
          return complete();
        }
      });
    };
    keys = {
      tokens: [],
      bound: false,
      bind: function() {
        if (this.bound) {
          return;
        }
        this.tokens.push($.subscribe("/keyboard/arrow", function(key) {
          var position;
          position = index % pageSize;
          switch (key) {
            case "left":
              if (index % columns > 0) {
                return at(index - 1, true);
              }
              break;
            case "right":
              if (index % columns < columns - 1) {
                return at(index + 1, true);
              }
              break;
            case "up":
              if (position >= columns) {
                return at(index - columns, true);
              }
              break;
            case "down":
              if (position < (rows - 1) * columns) {
                return at(index + columns, true);
              }
          }
        }));
        this.tokens.push($.subscribe("/keyboard/page", function(dir) {
          if (dir === "down") {
            page(-1);
          }
          if (dir === "up") {
            return page(1);
          }
        }));
        this.tokens.push($.subscribe("/keyboard/enter", function() {
          return at(index % pageSize);
        }));
        return this.bound = true;
      },
      unbind: function() {
        if (!this.bound) {
          return;
        }
        this.tokens = $.map(this.tokens, function(item) {
          return $.unsubscribe(item);
        });
        return this.bound = false;
      }
    };
    arrows = {
      left: null,
      right: null,
      both: null,
      init: function(parent) {
        arrows.left = parent.find(".previous");
        arrows.left.hide();
        arrows.right = parent.find(".next");
        return arrows.both = $([arrows.left[0], arrows.right[0]]);
      }
    };
    return pub = {
      before: function(e) {
        $.publish("/postman/deliver", [
          {
            paused: true
          }, "/camera/pause"
        ]);
        return keys.bind();
      },
      hide: function(e) {
        keys.unbind();
        pages.next.empty();
        return pages.previous.empty();
      },
      show: function(e) {
        return setTimeout(render, 420);
      },
      previous: function(e) {
        return page(1);
      },
      next: function(e) {
        return page(-1);
      },
      swipe: function(e) {
        return page((e.direction === "right") - (e.direction === "left"));
      },
      click: function(e) {
        var thumb;
        thumb = this.element;
        $.publish("/galleryBar/update", ["selected"]);
        return select(thumb.data("name"));
      },
      init: function(selector) {
        var list, page1, page2, thumbnails;
        list = $(selector);
        thumbnails = $("#thumbnails", list);
        page1 = new kendo.View(thumbnails, null);
        page2 = new kendo.View(thumbnails, null);
        container = page1.container;
        arrows.init($(list));
        pages.previous = page1.render().addClass("page gallery");
        active = pages.next = page2.render().addClass("page gallery");
        $.subscribe("/gallery/details", function(d) {
          details = d;
          return updateLocation();
        });
        $.subscribe("/gallery/delete", function() {
          return destroy();
        });
        $.subscribe("/gallery/add", function(item) {
          return add(item);
        });
        $.subscribe("/gallery/at", function(index) {
          return at(index);
        });
        $.subscribe("/details/hiding", function() {
          return list.show();
        });
        $.subscribe("/details/shown", function() {
          return list.hide();
        });
        $.subscribe("/gallery/clear", function() {
          $.publish("/bottom/thumbnail");
          return filewrapper.clear().done(function() {
            return clear();
          });
        });
        $.subscribe("/gallery/keyboard", function(bind) {
          if (bind) {
            return keys.bind();
          } else {
            return keys.unbind();
          }
        });
        filewrapper.fileListing().done(function(message) {
          ds = dataSource.create(message);
          ds.read();
          if (ds.view().length > 0) {
            return filewrapper.readFile(ds.view()[0]).done(function(file) {
              return $.publish("/bottom/thumbnail", [file]);
            });
          }
        });
        return gallery;
      }
    };
  });

}).call(this);

define('text!mylibs/gallery/views/details.html',[],function () { return '<section class="details">\n\n    <img data-bind="invisible: isVideo, attr: { src: img.src }" width="720" height="540">\n\n    <span class="previous" data-bind="visible: previous.visible" data-role="clickable" data-tabbable tabindex="0" data-click="APP.details.previous">&lsaquo;</span>\n    <span class="next" data-bind="visible: next.visible" data-role="clickable" data-tabbable tabindex="0" data-click="APP.details.next">&rsaquo;</span>\n\n</section>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/gallery/details',['Kendo', 'mylibs/utils/utils', 'mylibs/file/filewrapper', 'text!mylibs/gallery/views/details.html'], function(kendo, utils, filewrapper, template) {
    var details, hide, index, keys, page, pub, show, token, tokens, update, viewModel, visible;
    index = 0;
    visible = false;
    details = {};
    tokens = {};
    token = null;
    viewModel = kendo.observable({
      video: {
        src: function() {
          return utils.placeholder.image();
        }
      },
      img: {
        src: function() {
          return utils.placeholder.image();
        }
      },
      type: "jpeg",
      isVideo: function() {
        return this.get("type") === "webm";
      },
      next: {
        visible: false
      },
      previous: {
        visible: false
      }
    });
    page = function(direction) {
      if (!visible) {
        return;
      }
      if (direction === "left" && viewModel.previous.visible) {
        pub.previous();
      }
      if (direction === "right" && viewModel.next.visible) {
        pub.next();
      }
      return false;
    };
    hide = function() {
      $.publish("/galleryBar/update", ["gallery"]);
      $.publish("/gallery/keyboard", [true]);
      $.publish("/details/hiding");
      keys.unbind();
      return kendo.fx(details.container).zoom("out").play().done(function() {
        $.unsubscribe(tokens["delete"]);
        return tokens["delete"] = null;
      });
    };
    show = function(message) {
      update(message);
      keys.bind();
      tokens["delete"] = $.subscribe("/gallery/delete", function() {
        return hide();
      });
      return kendo.fx(details.container).zoom("in").play().done(function() {
        $.publish("/details/shown");
        return $.publish("/galleryBar/update", ["details"]);
      });
    };
    update = function(message) {
      var _this = this;
      if (visible) {
        $.publish("/galleryBar/location", [
          {
            visible: true,
            text: "Photo " + (message.index + 1) + " of " + message.length
          }
        ]);
      }
      return filewrapper.readFile(message.item).done(function(data) {
        viewModel.set("type", message.item.type);
        viewModel.set("img.src", data.file);
        viewModel.set("next.visible", message.index < message.length - 1);
        viewModel.set("previous.visible", message.index > 0 && message.length > 1);
        return index = message.index;
      });
    };
    keys = {
      bound: false,
      bind: function() {
        if (this.bound) {
          return;
        }
        tokens.arrow = $.subscribe("/keyboard/arrow", page, true);
        tokens.esc = $.subscribe("/keyboard/esc", hide);
        return this.bound = true;
      },
      unbind: function() {
        if (!this.bound) {
          return;
        }
        $.unsubscribe(tokens.arrow);
        $.unsubscribe(tokens.esc);
        return this.bound = false;
      }
    };
    return pub = {
      init: function(selector) {
        var that,
          _this = this;
        that = this;
        details = new kendo.View(selector, template);
        details.render(viewModel, true);
        $.subscribe("/details/hide", function() {
          visible = false;
          return hide();
        });
        $.subscribe("/details/show", function(message) {
          visible = true;
          return show(message);
        });
        $.subscribe("/details/update", function(message) {
          return update(message);
        });
        return $.subscribe("/details/keyboard", function(bind) {
          if (bind) {
            return keys.bind();
          } else {
            return keys.unbind();
          }
        });
      },
      next: function(e) {
        return $.publish("/gallery/at", [index + 1]);
      },
      previous: function(e) {
        return $.publish("/gallery/at", [index - 1]);
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/events/events',['mylibs/utils/utils'], function(utils) {
    var pub;
    return pub = {
      init: function() {
        var p;
        p = function(name, key) {
          return $.publish("/keyboard/" + name, [key]);
        };
        return $(document).keydown(function(e) {
          switch (e.which) {
            case utils.keys.arrows.left:
              return p("arrow", "left");
            case utils.keys.arrows.right:
              return p("arrow", "right");
            case utils.keys.arrows.up:
              return p("arrow", "up");
            case utils.keys.arrows.down:
              return p("arrow", "down");
            case utils.keys.esc:
              return p("esc", "esc");
            case utils.keys.space:
              return p("space", {
                ctrlKey: e.ctrlKey || e.metaKey
              });
            case utils.keys.w:
              if (e.ctrlKey || e.metaKey) {
                return p("close");
              }
              break;
            case utils.keys.enter:
              return p("enter");
            case utils.keys.page.up:
              return p("page", "up");
            case utils.keys.page.down:
              return p("page", "down");
          }
        });
      }
    };
  });

}).call(this);

define('text!mylibs/about/views/about.html',[],function () { return '<section class="about">\n    <hgroup class="appInfoHeader">\n        <h1 data-bind="localeText: appName"></h1>\n        <h2>Version 1.0</h2>\n    </hgroup>\n    <div>\n        <hgroup>\n            <h3 data-bind="localeHtml: about_kendo"></h3>\n            <h4 data-bind="localeHtml: about_kendo_license"></h4>\n            <h5 data-bind="localeText: about_credits"></h5>\n        </hgroup>\n    </div>\n    <button data-role="button" data-click="APP.about.clear" data-tabbable tabindex="0" data-bind="localeText: clear_gallery_button" class="button"></button>\n    <button data-role="button" data-click="APP.about.back" data-tabbable tabindex="0" data-bind="localeText: back_button" class="button back"></button>\n</section>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/about/about',['Kendo', 'mylibs/navigation/navigation', 'text!mylibs/about/views/about.html'], function(kendo, navigation, template) {
    var click, previous, pub, viewModel;
    previous = "#home";
    viewModel = kendo.observable({});
    click = function(e) {
      return $.publish("/postman/deliver", [
        {
          link: e.target.href
        }, "/link/open"
      ]);
    };
    return pub = {
      before: function() {
        return $.publish("/postman/deliver", [
          {
            paused: true
          }, "/camera/pause"
        ]);
      },
      init: function(selector) {
        var view;
        view = new kendo.View(selector, template);
        view.render(viewModel, true);
        view.find("a").on("click", click);
        return $.subscribe('/menu/click/chrome-cam-about-menu', function() {
          $.publish("/postman/deliver", [false, "/menu/enable"]);
          previous = window.APP.app.view().id;
          return navigation.navigate(selector);
        });
      },
      back: function() {
        $.publish("/postman/deliver", [true, "/menu/enable"]);
        return navigation.navigate(previous);
      },
      clear: function() {
        return $.publish("/confirm/show", [
          window.APP.localization.clear_gallery_dialog_title, window.APP.localization.clear_gallery_confirmation, function(destroy) {
            if (destroy) {
              $.publish("/gallery/clear");
              return navigation.navigate("#home");
            }
          }
        ]);
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/confirm/confirm',['Kendo'], function(kendo) {
    var callback, close, open, pub, view;
    view = {};
    callback = null;
    open = false;
    close = function(result) {
      view.data("kendoMobileModalView").close();
      $.publish("/tabbing/restore", [$(document.body)]);
      $(document.body).focus();
      open = false;
      if (callback) {
        return callback(result);
      }
    };
    return pub = {
      yes: function(e) {
        return close(true);
      },
      no: function(e) {
        return close(false);
      },
      init: function(selector) {
        var esc;
        view = $(selector);
        $.subscribe("/confirm/show", function(title, message, cb) {
          callback = cb;
          view.find(".title").html(title);
          view.find(".message").html(message);
          view.find(".yes").text(window.APP.localization.yesButton);
          view.find(".no").text(window.APP.localization.noButton);
          view.data("kendoMobileModalView").open();
          $.publish("/tabbing/remove", [$(document.body)]);
          $.publish("/tabbing/restore", [view]);
          setTimeout((function() {
            return view.find(".yes").focus();
          }), 250);
          return open = true;
        });
        esc = function() {
          if (open) {
            pub.no();
            return false;
          }
        };
        return $.subscribe("/keyboard/esc", esc, true);
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/assets/assets',[], function() {
    /*		Asset Pipline		
    
    	The asset pipeline recieves base 64 encoded images from the extension and exposes them 
    	locally as images. This is because the sandbox treats any local resources as tainted 
    	and won't allow reading them from a canvas as image data
    */

    var assets, pub;
    assets = {};
    return pub = {
      images: assets,
      init: function() {
        $.subscribe("/assets/add", function(message) {
          var img;
          img = new Image;
          img.src = message.message.image;
          return assets[message.message.name] = img;
        });
        return $.publish("/postman/deliver", [{}, "/assets/get"]);
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/tabbing/tabbing',['mylibs/utils/utils'], function(utils) {
    var keydown, pub, removeTabs, restoreTabs;
    keydown = function(e) {
      var target;
      if (!(e.which === utils.keys.space || e.which === utils.keys.enter)) {
        return;
      }
      target = $(e.target);
      if (target.data("role") === "button") {
        return target.data("kendoMobileButton").trigger("click", e);
      } else if (target.data("role") === "clickable") {
        return target.data("kendoMobileClickable").trigger("click", e);
      }
    };
    removeTabs = function(parent) {
      return $("[tabindex]", parent).each(function() {
        var tabbable;
        tabbable = $(this);
        tabbable.attr("data-old-tabindex", tabbable.attr("tabindex"));
        return tabbable.attr("tabindex", -1);
      });
    };
    restoreTabs = function(parent) {
      return $("[data-old-tabindex]", parent).each(function() {
        var tabbable;
        tabbable = $(this);
        tabbable.attr("tabindex", tabbable.attr("data-old-tabindex"));
        return tabbable.removeAttr("data-old-tabindex");
      });
    };
    return pub = {
      init: function() {
        $(document.body).on("keydown", "[data-tabbable]", keydown);
        $.subscribe("/tabbing/remove", removeTabs);
        return $.subscribe("/tabbing/restore", restoreTabs);
      }
    };
  });

}).call(this);

define('text!mylibs/nocamera/views/nocamera.html',[],function () { return '<section class="about no-camera">\n\t<hgroup class="appInfoHeader">\n\t\t<h1 data-bind="localeText: no_camera_heading"></h1>\n\t\t<h2 data-bind="localeText: no_camera_description"></h2>\n\t</hgroup>\n\t<div>\n\t\t<div data-bind="localeHtml: no_camera_resolution"></div>\n\t</div>\n</section>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('app',['Kendo', 'mylibs/bar/bottom', 'mylibs/bar/galleryBar', 'mylibs/popover/popover', 'mylibs/full/full', 'mylibs/postman/postman', 'mylibs/utils/utils', 'mylibs/gallery/gallery', 'mylibs/gallery/details', 'mylibs/events/events', 'mylibs/file/filewrapper', 'mylibs/about/about', 'mylibs/confirm/confirm', 'mylibs/assets/assets', 'mylibs/navigation/navigation', 'mylibs/tabbing/tabbing', "text!mylibs/nocamera/views/nocamera.html"], function(kendo, bottom, galleryBar, popover, full, postman, utils, gallery, details, events, filewrapper, about, confirm, assets, navigation, tabbing, nocamera) {
    var pub;
    return pub = {
      init: function() {
        var APP, promises;
        APP = window.APP = {};
        APP.full = full;
        APP.gallery = gallery;
        APP.about = about;
        APP.confirm = confirm;
        APP.bottom = bottom;
        APP.galleryBar = galleryBar;
        APP.details = details;
        events.init();
        postman.init(window.top);
        assets.init();
        $.subscribe('/camera/unsupported', function() {
          new kendo.View("#no-camera", nocamera).render(kendo.observable({}), true);
          return navigation.navigate("#no-camera");
        });
        $.publish("/postman/deliver", [true, "/menu/enable"]);
        promises = {
          effects: $.Deferred(),
          localization: $.Deferred()
        };
        $.subscribe("/effects/response", function(filters) {
          APP.filters = filters;
          return promises.effects.resolve();
        });
        $.subscribe("/localization/response", function(dict) {
          APP.localization = dict;
          return promises.localization.resolve();
        });
        $.when(promises.effects.promise(), promises.localization.promise()).then(function() {
          var hideSplash;
          bottom.init(".bottom");
          galleryBar.init(".galleryBar");
          APP.popover = popover.init("#gallery");
          full.init("#capture");
          details.init("#details");
          gallery.init("#list");
          about.init("#about");
          confirm.init("#confirm");
          full.show(APP.filters[0]);
          tabbing.init();
          $.publish("/postman/deliver", [
            {
              message: ""
            }, "/app/ready"
          ]);
          window.APP.app = new kendo.mobile.Application(document.body, {
            platform: "android"
          });
          hideSplash = function() {
            return $("#splash").kendoAnimate({
              effects: "fade:out",
              duration: 1000,
              hide: true
            });
          };
          setTimeout(hideSplash, 100);
          return $.subscribe("/keyboard/close", function() {
            return $.publish("/postman/deliver", [null, "/window/close"]);
          });
        });
        $.publish("/postman/deliver", [null, "/localization/request"]);
        return $.publish("/postman/deliver", [null, "/effects/request"]);
      }
    };
  });

}).call(this);

/*

	jQuery pub/sub plugin by Peter Higgins (dante@dojotoolkit.org)

	Loosely based on Dojo publish/subscribe API, limited in scope. Rewritten blindly.

	Original is (c) Dojo Foundation 2004-2010. Released under either AFL or new BSD, see:
	http://dojofoundation.org/license for more information.

	Minor tweak by us.

*/

;(function(d){

	// the topic/subscription hash
	var cache = {};

	d.publish = function(/* String */topic, /* Array? */args){
		// summary:
		//		Publish some data on a named topic.
		// topic: String
		//		The channel to publish on
		// args: Array?
		//		The data to publish. Each array item is converted into an ordered
		//		arguments on the subscribed functions.
		//
		// example:
		//		Publish stuff on '/some/topic'. Anything subscribed will be called
		//		with a function signature like: function(a,b,c){ ... }
		//
		//	|		$.publish("/some/topic", ["a","b","c"]);
		if (cache[topic]) {
			cache[topic].forEach(function(fn) {
				return fn.apply(null, args || []);
			});
		}
	};

	d.subscribe = function(/* String */topic, /* Function */callback, /* Boolean? */ first){
		// summary:
		//		Register a callback on a named topic.
		// topic: String
		//		The channel to subscribe to
		// callback: Function
		//		The handler event. Anytime something is $.publish'ed on a
		//		subscribed channel, the callback will be called with the
		//		published array as ordered arguments.
		//
		// returns: Array
		//		A handle which can be used to unsubscribe this particular subscription.
		//
		// example:
		//	|	$.subscribe("/some/topic", function(a, b, c){ /* handle data */ });
		//
		if(!cache[topic]){
			cache[topic] = [];
		}
		if (first) {
			cache[topic].unshift(callback);
		} else {
			cache[topic].push(callback);
		}
		return [topic, callback]; // Array
	};

	d.unsubscribe = function(/* Array */handle){
		// summary:
		//		Disconnect a subscribed function for a topic.
		// handle: Array
		//		The return value from a $.subscribe call.
		// example:
		//	|	var handle = $.subscribe("/something", function(){});
		//	|	$.unsubscribe(handle);

		var t = handle[0];
		cache[t] && d.each(cache[t], function(idx){
			if(this == handle[1]){
				cache[t].splice(idx, 1);
			}
		});
	};

})(jQuery);

define("libs/jquery/pubsub", function(){});

// Generated by CoffeeScript 1.4.0
(function() {

  define('libs/jquery/plugins',['order!libs/jquery/pubsub'], function() {});

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  require.config({
    paths: {
      Kendo: 'libs/kendo/kendo'
    }
  });

  require(['app', 'order!libs/jquery/plugins'], function(app) {
    return app.init();
  });

}).call(this);

define("main", function(){});
