
/*
 RequireJS order 1.0.5 Copyright (c) 2010-2011, The Dojo Foundation All Rights Reserved.
 Available via the MIT or new BSD license.
 see: http://github.com/jrburke/requirejs for details
*/
(function(){function k(a){var b=a.currentTarget||a.srcElement,c;if(a.type==="load"||l.test(b.readyState)){a=b.getAttribute("data-requiremodule");j[a]=!0;for(a=0;c=g[a];a++)if(j[c.name])c.req([c.name],c.onLoad);else break;a>0&&g.splice(0,a);setTimeout(function(){b.parentNode.removeChild(b)},15)}}function m(a){var b,c;a.setAttribute("data-orderloaded","loaded");for(a=0;c=h[a];a++)if((b=i[c])&&b.getAttribute("data-orderloaded")==="loaded")delete i[c],require.addScriptToDom(b);else break;a>0&&h.splice(0,
a)}var f=typeof document!=="undefined"&&typeof window!=="undefined"&&document.createElement("script"),n=f&&(f.async||window.opera&&Object.prototype.toString.call(window.opera)==="[object Opera]"||"MozAppearance"in document.documentElement.style),o=f&&f.readyState==="uninitialized",l=/^(complete|loaded)$/,g=[],j={},i={},h=[],f=null;define('order',{version:"1.0.5",load:function(a,b,c,e){var d;b.nameToUrl?(d=b.nameToUrl(a,null),require.s.skipAsync[d]=!0,n||e.isBuild?b([a],c):o?(e=require.s.contexts._,!e.urlFetched[d]&&
!e.loaded[a]&&(e.urlFetched[d]=!0,require.resourcesReady(!1),e.scriptCount+=1,d=require.attach(d,e,a,null,null,m),i[a]=d,h.push(a)),b([a],c)):b.specified(a)?b([a],c):(g.push({name:a,req:b,onLoad:c}),require.attach(d,null,a,k,"script/cache"))):b([a],c)}})})();

(function($) {

    var View;
    return kendo.View = (function() {

      // view constructor. takes in the container or selector
      // a template, and the data for the template if any
      function View(container, template, data) {
        // if a container element is specified
        if (container) {
          // if the container is a jquery object
          if (this.container instanceof $) {
            // set the internal reference
            this.container = container 
          }
          // otherwise
          else {
            // set the internal reference to a jQuery instance
            // TODO: should probably check that this is a string
            //       before trying to wrap it
            this.container = $(container);
          }
        }
        // otherwise return an empty div as the container
        else this.container = $("<div></div>");
        
        // set the internal data object to the data passed in,
        // or an empty object if nothing was passed
        this.data = data || {};
        // check to make sure we passed in a template
        // otherwise set it to an empty div
        template = template || "<div></div>";
        // create the kendo template object 
        this.template = kendo.template(template);
        // create an el object that will hold all references to 
        // DOM objects in the view as specified by the "find" method
        this.el = {};
      };

      // renders the template and attaches it to the container. returns
      // a content object which is the template itself as DOM object, 
      // not the container
      View.prototype.render = function(viewModel, bind) {
        // render the kendo template and append it to the container
        this.content = $(this.template(this.data)).appendTo(this.container);
        // if a view model was passed in
        if (viewModel) {
          // set the viewModel variable equal to it
          this.viewModel = viewModel;
            // check if bind was specified. it's not done automatically
            // since mobile views don't bind this way
            if (bind) {
              // bind the container to the view model
              kendo.bind(this.content, this.viewModel);
            }
        }
        // return the template content as a DOM object
        return this.content; 
      };

      // binds the container to the view model
      View.prototype.bind = function(viewModel) {
        this.viewModel = viewModel
        kendo.bind(this.container, this.viewModel)
      };

      // the find method does a simle jQuery find and caches
      // the matched object if a cache string is specified.
      // all cached objects are available off of the el object.
      View.prototype.find = function(selector, cache) {
        // execute the find
        // TODO: Make sure selector is a string
        var match = this.container.find(selector);
        // if a cache is specified
        if (cache) {
          // cache match on the el object by it's specified
          // name
          this.el[cache] = match;
        };
        // return the mached element
        return match;
      };

      View.prototype.destroy = function() {
        this.content.remove();
      }

      return View;

    })();

})(jQuery);
define("libs/kendo/kendo.view", function(){});

(function ($) {
	
	var ui = kendo.mobile.ui,
		Button = ui.Button,
		Widget = ui.Widget,
		support = kendo.support,
        os = support.mobileOS,
        ANDROID3UP = os.android && os.flatVersion >= 300;

	var Clickable = Button.extend({

		init: function (element, options) {

			var that = this;

            Widget.fn.init.call(that, element, options);

            that.element
                .on("up", "_release")
                .on("down", "_activate")
                .on("up cancel", "_deactivate")
                .on("mouseover", "_mouseover")
                .on("mouseout", "_mouseout")

            // add a pointer
            that.element.css("cursor", "pointer")

            if (ANDROID3UP) {
                that.element.on("move", "_timeoutDeactivate");
            }
		},

		options: {
			name: "Clickable"
		},

		_mouseover: function (e) {
			this.trigger("mouseover", { target: e.target });
		},

		_mouseout: function (e) {
			this.trigger("mouseout", { target: e.target });
		}
	});

	// add this new widget to the UI namespace.
	ui.plugin(Clickable);

}(jQuery));
define("libs/kendo/kendo.mobile.clickable", function(){});

// Generated by CoffeeScript 1.4.0
(function() {

  kendo.data.binders.zoom = kendo.data.Binder.extend({
    refresh: function() {
      var value, visible;
      value = this.bindings["zoom"].get();
      visible = $(this.element).is(":visible");
      if (value) {
        if (!visible) {
          $(this.element).kendoStop(true).kendoAnimate({
            effects: "zoomIn fadeIn",
            show: true
          });
        }
      }
      if (!value && visible) {
        return $(this.element).kendoStop(true).kendoAnimate({
          effects: "zoomOut fadeOut",
          show: true
        });
      }
    }
  });

  kendo.data.binders.localeText = kendo.data.Binder.extend({
    refresh: function() {
      var text;
      text = APP.localization[this.bindings.localeText.path];
      if (text == null) {
        console.log("Missing localization for " + this.bindings.localeText.path + ", is it in localization.coffee?");
      }
      return $(this.element).text(text);
    }
  });

  kendo.data.binders.localeHtml = kendo.data.Binder.extend({
    refresh: function() {
      var html;
      html = APP.localization[this.bindings.localeHtml.path];
      if (html == null) {
        console.log("Missing localization for " + this.bindings.localeHtml.path + ", is it in localization.coffee?");
      }
      return $(this.element).html(html);
    }
  });

  kendo.data.binders.localeTitle = kendo.data.Binder.extend({
    refresh: function() {
      var title;
      title = APP.localization[this.bindings.localeTitle.path];
      if (title == null) {
        console.log("Missing localization for " + this.bindings.localeTitle.path + ", is it in localization.coffee?");
      }
      return $(this.element).attr("title", title);
    }
  });

}).call(this);

define("libs/kendo/kendo.custom.binders", function(){});

// Generated by CoffeeScript 1.4.0
(function() {

  define('Kendo',['order!libs/kendo/kendo.view', 'order!libs/kendo/kendo.mobile.clickable', 'order!libs/kendo/kendo.custom.binders'], function() {
    return kendo;
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/file/filewrapper',[], function(file) {
    var asyncFileRequest, pub;
    asyncFileRequest = function(requestMessage, responseMessage, data) {
      var deferred, token;
      deferred = $.Deferred();
      token = $.subscribe(responseMessage, function(result) {
        $.unsubscribe(token);
        return deferred.resolve((result || {}).message);
      });
      $.publish("/postman/deliver", [data, requestMessage, []]);
      return deferred.promise();
    };
    return pub = window.filewrapper = {
      readAll: function() {
        return asyncFileRequest("/file/read", "/pictures/bulk", {});
      },
      deleteFile: function(filename) {
        return asyncFileRequest("/file/delete", "/file/deleted/" + filename, {
          name: filename
        });
      },
      clear: function() {
        return asyncFileRequest("/file/clear", "/file/cleared", {});
      },
      save: function(filename, blob) {
        return asyncFileRequest("/file/save", "/file/saved/" + filename, {
          name: filename,
          file: blob
        });
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/utils/utils',['mylibs/file/filewrapper'], function(filewrapper) {
    /*     Utils
    
    This file contains utility functions and normalizations. This used to contain more functions, but
    most have been moved into the extension.
    */

    var pub;
    return pub = {
      placeholder: {
        image: function() {
          return "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
        }
      },
      oppositeDirectionOf: function(dir) {
        switch (dir) {
          case "left":
            return "right";
          case "right":
            return "left";
          case "up":
            return "down";
          case "down":
            return "up";
        }
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/navigation/navigation',[], function() {
    

    var callbacks, pub;
    callbacks = {
      to: {},
      from: {}
    };
    return pub = {
      navigate: function(view) {
        var callback, deferreds, previous, _i, _j, _len, _len1, _ref, _ref1;
        deferreds = [];
        previous = window.APP.app.view().id;
        if (previous in callbacks.from) {
          _ref = callbacks.from[previous];
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            callback = _ref[_i];
            deferreds.push(callback());
          }
        }
        if (view in callbacks.to) {
          _ref1 = callbacks.to[view];
          for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
            callback = _ref1[_j];
            deferreds.push(callback());
          }
        }
        return $.when.apply($, deferreds).done(function() {
          return window.APP.app.navigate(view);
        });
      },
      navigating: {
        to: function(view, callback) {
          if (!(view in callbacks.to)) {
            callbacks.to[view] = [];
          }
          return callbacks.to[view].push(callback);
        },
        from: function(view, callback) {
          if (!(view in callbacks.from)) {
            callbacks.from[view] = [];
          }
          return callbacks.from[view].push(callback);
        }
      }
    };
  });

}).call(this);

/*
 RequireJS text 1.0.6 Copyright (c) 2010-2011, The Dojo Foundation All Rights Reserved.
 Available via the MIT or new BSD license.
 see: http://github.com/jrburke/requirejs for details
*/
(function(){var k=["Msxml2.XMLHTTP","Microsoft.XMLHTTP","Msxml2.XMLHTTP.4.0"],n=/^\s*<\?xml(\s)+version=[\'\"](\d)*.(\d)*[\'\"](\s)*\?>/im,o=/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im,i=typeof location!=="undefined"&&location.href,p=i&&location.protocol&&location.protocol.replace(/\:/,""),q=i&&location.hostname,r=i&&(location.port||void 0),j=[];define('text',[],function(){var g,h,l;typeof window!=="undefined"&&window.navigator&&window.document?h=function(a,c){var b=g.createXhr();b.open("GET",a,!0);b.onreadystatechange=
function(){b.readyState===4&&c(b.responseText)};b.send(null)}:typeof process!=="undefined"&&process.versions&&process.versions.node?(l=require.nodeRequire("fs"),h=function(a,c){var b=l.readFileSync(a,"utf8");b.indexOf("\ufeff")===0&&(b=b.substring(1));c(b)}):typeof Packages!=="undefined"&&(h=function(a,c){var b=new java.io.File(a),e=java.lang.System.getProperty("line.separator"),b=new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(b),"utf-8")),d,f,g="";try{d=new java.lang.StringBuffer;
(f=b.readLine())&&f.length()&&f.charAt(0)===65279&&(f=f.substring(1));for(d.append(f);(f=b.readLine())!==null;)d.append(e),d.append(f);g=String(d.toString())}finally{b.close()}c(g)});return g={version:"1.0.6",strip:function(a){if(a){var a=a.replace(n,""),c=a.match(o);c&&(a=c[1])}else a="";return a},jsEscape:function(a){return a.replace(/(['\\])/g,"\\$1").replace(/[\f]/g,"\\f").replace(/[\b]/g,"\\b").replace(/[\n]/g,"\\n").replace(/[\t]/g,"\\t").replace(/[\r]/g,"\\r")},createXhr:function(){var a,c,
b;if(typeof XMLHttpRequest!=="undefined")return new XMLHttpRequest;else for(c=0;c<3;c++){b=k[c];try{a=new ActiveXObject(b)}catch(e){}if(a){k=[b];break}}if(!a)throw Error("createXhr(): XMLHttpRequest not available");return a},get:h,parseName:function(a){var c=!1,b=a.indexOf("."),e=a.substring(0,b),a=a.substring(b+1,a.length),b=a.indexOf("!");b!==-1&&(c=a.substring(b+1,a.length),c=c==="strip",a=a.substring(0,b));return{moduleName:e,ext:a,strip:c}},xdRegExp:/^((\w+)\:)?\/\/([^\/\\]+)/,useXhr:function(a,
c,b,e){var d=g.xdRegExp.exec(a),f;if(!d)return!0;a=d[2];d=d[3];d=d.split(":");f=d[1];d=d[0];return(!a||a===c)&&(!d||d===b)&&(!f&&!d||f===e)},finishLoad:function(a,c,b,e,d){b=c?g.strip(b):b;d.isBuild&&(j[a]=b);e(b)},load:function(a,c,b,e){if(e.isBuild&&!e.inlineText)b();else{var d=g.parseName(a),f=d.moduleName+"."+d.ext,m=c.toUrl(f),h=e&&e.text&&e.text.useXhr||g.useXhr;!i||h(m,p,q,r)?g.get(m,function(c){g.finishLoad(a,d.strip,c,b,e)}):c([f],function(a){g.finishLoad(d.moduleName+"."+d.ext,d.strip,a,
b,e)})}},write:function(a,c,b){if(c in j){var e=g.jsEscape(j[c]);b.asModule(a+"!"+c,"define(function () { return '"+e+"';});\n")}},writeFile:function(a,c,b,e,d){var c=g.parseName(c),f=c.moduleName+"."+c.ext,h=b.toUrl(c.moduleName+"."+c.ext)+".js";g.load(f,b,function(){var b=function(a){return e(h,a)};b.asModule=function(a,b){return e.asModule(a,h,b)};g.write(a,f,b,d)},d)}}})})();

define('text!mylibs/bar/views/bottom.html',[],function () { return '<section class="bar">\n    <section class="left">\n        <a data-role="button" class="button filters" data-click="APP.bottom.filters" data-bind="visible: filters.visible, localeText: filters_button"></a>\n        <span class="mode" data-bind="visible: mode.visible">\n            <a data-role="button" data-click="APP.bottom.mode" data-bind="localeTitle: photo" class="selected" data-mode="photo"><img src="styles/images/singleMode.png"></a><a data-role="button" data-click="APP.bottom.mode" data-mode="paparazzi" data-bind="localeTitle: paparazzi" data-mode="paparazzi"><img src="styles/images/papparazziMode.png"></a>\n            <!-- <a data-mode="video" class="km-button" data-bind="click: mode.click" data-mode="video" alt="Video" title="Video"><img src="styles/images/videoMode.png"></a> -->\n        </span>\n    </section>\n    <section class="center">\n        <a data-role="button" data-click="APP.bottom.capture" class="km-button capture photo" data-bind="visible: capture.visible"><img src="styles/images/capture.png" class="photo"></a>\n        <div class="countdown">\n            <span class="circle counter">\n                <span class="red-dot"></span>\n            </span>\n            <span class="circle counter">\n                <span class="red-dot"></span>\n            </span>\n            <span class="circle counter">\n                <span class="red-dot"></span>\n            </span>\n        </div>\n        <div class="saving" data-bind="visible: processing.visible">\n            <h3>Processing...</h3>\n        </div>\n    </section>\n    <section class="right">\n        <div class="thumbnail">\n            <div class="absolute" id="destination" class="thumbnail" ></div>\n            <div class="absolute">\n                <a data-role="clickable" data-click="APP.bottom.gallery" data-bind="visible: thumbnail.visible, localeTitle: gallery" class="galleryLink"></a>\n            </div>\n        <div>\n    </section>\n</section>';});

define('text!mylibs/bar/views/thumbnail.html',[],function () { return '# if (type === \'webm\') { # \n\t<video src="#: file #" class="thumbnail"></video>\n# } else { #\n\t<img src="#: file #" class="thumbnail">\n# } #';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/bar/bottom',['Kendo', 'mylibs/utils/utils', 'mylibs/navigation/navigation', 'text!mylibs/bar/views/bottom.html', 'text!mylibs/bar/views/thumbnail.html'], function(kendo, utils, navigation, template, thumbnailTemplate) {
    var BROKEN_IMAGE, countdown, paused, pub, states, view, viewModel;
    BROKEN_IMAGE = utils.placeholder.image();
    paused = false;
    view = {};
    viewModel = kendo.observable({
      processing: {
        visible: false
      },
      mode: {
        visible: false,
        active: "photo"
      },
      capture: {
        visible: true
      },
      thumbnail: {
        src: BROKEN_IMAGE,
        visible: function() {
          return this.get("enabled") && this.get("active");
        },
        enabled: false,
        active: true
      },
      filters: {
        visible: false,
        open: false,
        css: function() {}
      }
    });
    countdown = function(position, callback) {
      return $("span", view.el.counters[position]).kendoStop(true).kendoAnimate({
        effects: "zoomIn fadeIn",
        duration: 200,
        show: true,
        complete: function() {
          ++position;
          if (position < 3) {
            return setTimeout(function() {
              return countdown(position, callback);
            }, 500);
          } else {
            callback();
            view.el.counters.hide();
            return $("span", view.el.counters).hide();
          }
        }
      });
    };
    states = {
      capture: function() {
        viewModel.set("mode.visible", false);
        viewModel.set("capture.visible", false);
        return viewModel.set("filters.visible", false);
      },
      full: function() {
        viewModel.set("mode.visible", true);
        viewModel.set("capture.visible", true);
        return viewModel.set("filters.visible", true);
      },
      set: function(state) {
        return this[state]();
      }
    };
    return pub = {
      pause: function(pausing) {
        return paused = pausing;
      },
      init: function(container) {
        view = new kendo.View(container, template);
        view.render(viewModel, true);
        view.find(".galleryLink", "galleryLink");
        $.subscribe("/bottom/update", function(state) {
          return states.set(state);
        });
        $.subscribe("/bottom/thumbnail", function(file) {
          var thumbnail;
          view.el.galleryLink.empty();
          if (file) {
            thumbnail = new kendo.View(view.el.galleryLink, thumbnailTemplate, file);
            thumbnail.render();
            return viewModel.set("thumbnail.enabled", true);
          } else {
            return viewModel.set("thumbnail.enabled", false);
          }
        });
        $.subscribe("/keyboard/space", function(e) {
          if (paused) {
            return;
          }
          if (viewModel.get("capture.visible")) {
            return pub.capture(e);
          }
        });
        view.find(".stop", "stop");
        view.find(".counter", "counters");
        view.find(".bar", "bar");
        view.find(".filters", "filters");
        view.find(".capture", "capture");
        return view;
      },
      capture: function(e) {
        var capture, mode;
        mode = viewModel.get("mode.active");
        $.publish("/full/capture/begin", [mode]);
        states.capture();
        capture = function() {
          $.publish("/capture/" + mode);
          return $.publish("/full/capture/end");
        };
        $.publish("/countdown/" + mode);
        if (event.ctrlKey || event.metaKey) {
          return capture();
        } else {
          view.el.counters.css({
            "display": "block"
          });
          return countdown(0, capture);
        }
      },
      filters: function(e) {
        viewModel.set("filters.open", !viewModel.filters.open);
        view.el.filters.toggleClass("selected", viewModel.filters.open);
        return $.publish("/full/filters/show", [viewModel.filters.open]);
      },
      mode: function(e) {
        var a;
        a = $(e.target).closest("a");
        viewModel.set("mode.active", a.data("mode"));
        a.closest(".bar").find("a").removeClass("selected");
        return a.addClass("selected");
      },
      gallery: function() {
        return navigation.navigate("#gallery");
      }
    };
  });

}).call(this);

define('text!mylibs/bar/views/top.html',[],function () { return '<section class="bar">\n\t<section class="left">\n\t\t<a data-role="button" data-click="APP.top.home" data-bind="invisible: back.details, localeText: back_to_camera_button"></a>\n\t\t<a data-role="button" data-click="APP.top.back" data-bind="visible: back.details, localeText: back_to_gallery_button" class="back button"></a>\n\t</section>\n\t<section class="center"></section>\n\t<section class="right">\n\t\t<a data-role="button" data-click="APP.top.destroy" data-bind="visible: selected" data-rel="popover" >\n\t\t\t<img src="styles/images/trashcan.png">\n\t\t</a>\n\t\t<a data-role="button" data-click="APP.top.save" data-bind="visible: selected, localeText: save_button" class="kd-button-action"></a>\n\t</section>\n</section>\n\n\n';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/bar/top',['Kendo', 'mylibs/navigation/navigation', 'text!mylibs/bar/views/top.html'], function(kendo, navigation, template) {
    var pub, states, viewModel,
      _this = this;
    viewModel = kendo.observable({
      current: null,
      selected: false,
      back: {
        details: false,
        text: "< Camera"
      }
    });
    states = {
      selected: function() {
        return viewModel.set("selected", true);
      },
      deselected: function() {
        return viewModel.set("selected", false);
      },
      details: function() {
        viewModel.set("back.text", "< Gallery");
        viewModel.set("back.details", true);
        return $.publish("/gallery/details", [true]);
      },
      gallery: function() {
        viewModel.set("back.text", "< Camera");
        viewModel.set("back.details", false);
        return $.publish("/gallery/details", [false]);
      },
      set: function(state) {
        states.current = state;
        return states[state]();
      }
    };
    return pub = {
      init: function(container) {
        var back;
        _this.view = new kendo.View(container, template);
        _this.view.render(viewModel, true);
        back = _this.view.find(".back.button");
        $.subscribe("/top/update", function(state) {
          return states.set(state);
        });
        $.subscribe("/item/selected", function(message) {
          return viewModel.set("current", message.item);
        });
        return $.subscribe("/keyboard/esc", function() {
          if (states.current === "details") {
            states.set("gallery");
            return back.trigger("click");
          }
        });
      },
      back: function(e) {
        $.publish("/details/hide");
        states.gallery();
        return e.preventDefault();
      },
      destroy: function(e) {
        return $.publish("/confirm/show", [
          window.APP.localization.delete_dialog_title, window.APP.localization.delete_confirmation, function() {
            return $.publish("/gallery/delete");
          }
        ]);
      },
      save: function(e) {
        var file;
        file = viewModel.get("current");
        return $.publish("/postman/deliver", [
          {
            name: file.name,
            file: file.file
          }, "/file/download"
        ]);
      },
      home: function(e) {
        return navigation.navigate("#home");
      }
    };
  });

}).call(this);

define('text!mylibs/popover/views/popover.html',[],function () { return '<div data-role="popover" id="popover" data-popup=\'{"height": 180, "width": 170}\'>\n    <div data-role="view">\n        <p>The selected image will be deleted.</p>\n\t\t<p><a data-bind="click: ok" class="button"><span>OK</span></a></p>\n\t\t<p><a data-bind="click: cancel" class="cancel button"><span>Cancel</span></a></p>\n    </div>\n</div>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/popover/popover',['Kendo', 'text!mylibs/popover/views/popover.html'], function(kendo, template) {
    var pub, viewModel;
    viewModel = {
      ok: function() {
        $.publish("/gallery/delete");
        return $("#popover").data("kendoMobilePopOver").close();
      },
      cancel: function() {
        return $("#popover").data("kendoMobilePopOver").close();
      }
    };
    return pub = {
      init: function(selector) {
        var view;
        view = new kendo.View(selector, template);
        return view.render(viewModel, true);
      }
    };
  });

}).call(this);

define('text!mylibs/full/views/full.html',[],function () { return '<div class="wrapper">\n    <h1 class="timer hidden"></h1>\n    <img class="snapshot">\n    <div class="filters-list hidden">\n        <ul>\n            # for (var i = 0; i < APP.filters.length; ++i) { #\n                <li data-role="clickable" data-click="APP.full.filter.click" data-bind="events: { mouseover: filter.mouseover, mouseout: filter.mouseout }" data-filter-index="#: i #" data-filter-id="#: APP.filters[i].id #">#: APP.filters[i].name #</li>\n            # } #\n        </ul>\n    </div>\n</div>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/full/full',['Kendo', 'mylibs/utils/utils', 'mylibs/file/filewrapper', 'mylibs/navigation/navigation', 'text!mylibs/full/views/full.html'], function(kendo, utils, filewrapper, navigation, template) {
    var capture, effectId, elements, frame, full, index, navigating, paparazzi, paused, pub, subscribe;
    paused = true;
    frame = 0;
    full = {};
    effectId = "";
    paparazzi = {};
    capture = function(callback, progress) {
      var captured;
      captured = $.subscribe("/captured/image", function(file) {
        $.unsubscribe(captured);
        $.publish("/gallery/add", [file]);
        return callback();
      });
      return $.publish("/postman/deliver", [progress, "/camera/capture"]);
    };
    index = {
      current: function() {
        var i, _i, _ref;
        for (i = _i = 0, _ref = APP.filters.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
          if (APP.filters.id === effectId) {
            return i;
          }
        }
      },
      max: function() {
        return APP.filters.length;
      },
      select: function(i) {
        return pub.select(APP.filters[i]);
      },
      preview: function(i) {
        return pub.select(APP.filters[i], true);
      },
      unpreview: function() {
        return pub.select(APP.filters[index.saved]);
      },
      saved: 0
    };
    subscribe = function(pub) {
      $.subscribe("/full/show", function(item) {
        return pub.show(item);
      });
      $.subscribe("/camera/snapshot", function(url) {
        return full.el.snapshot.attr("src", url);
      });
      $.subscribe("/capture/photo", function() {
        return pub.photo();
      });
      $.subscribe("/capture/paparazzi", function() {
        return pub.paparazzi();
      });
      $.subscribe("/countdown/paparazzi", function() {
        return full.el.paparazzi.removeClass("hidden");
      });
      $.subscribe("/full/filters/show", function(show) {
        var duration;
        duration = 200;
        if (show) {
          return full.el.filters.kendoStop().kendoAnimate({
            effects: "slideIn:right fade:in",
            show: true,
            hide: false,
            duration: duration
          });
        } else {
          return full.el.filters.kendoStop().kendoAnimate({
            effects: "slide:left fade:out",
            hide: true,
            show: false,
            duration: duration
          });
        }
      });
      $.subscribe("/full/capture/begin", function(mode) {
        $.publish("/postman/deliver", [mode, "/camera/capture/prepare"]);
        return full.el.wrapper.addClass("capturing");
      });
      $.subscribe("/full/capture/end", function() {
        return full.el.wrapper.removeClass("capturing");
      });
      return $.subscribe("/keyboard/arrow", function(dir) {
        if (paused) {
          return;
        }
        if (dir === "up" && index.current() > 0) {
          index.select(index.current() - 1);
        }
        if (dir === "down" && index.current() + 1 < index.max()) {
          return index.select(index.current() + 1);
        }
      });
    };
    elements = {
      cache: function(full) {
        full.find(".timer", "timer");
        full.find(".wrapper", "wrapper");
        full.find(".snapshot", "snapshot");
        full.find(".paparazzi", "paparazzi");
        return full.find(".filters-list", "filters");
      }
    };
    navigating = {
      to: function() {
        var deferred, updated;
        deferred = $.Deferred();
        APP.bottom.pause(false);
        updated = $.subscribe("/camera/updated", function() {
          var token;
          $.unsubscribe(updated);
          token = $.subscribe("/camera/snapshot/response", function(url) {
            $.unsubscribe(token);
            full.el.snapshot.attr("src", url);
            return deferred.resolve();
          });
          return $.publish("/postman/deliver", [null, "/camera/snapshot/request"]);
        });
        $.publish("/postman/deliver", [null, "/camera/update"]);
        return deferred.promise();
      },
      from: function() {
        var deferred, token;
        deferred = $.Deferred();
        APP.bottom.pause(true);
        token = $.subscribe("/camera/snapshot/response", function(url) {
          $.unsubscribe(token);
          full.el.snapshot.attr("src", url);
          return deferred.resolve();
        });
        $.publish("/postman/deliver", [null, "/camera/snapshot/request"]);
        return deferred.promise();
      }
    };
    return pub = {
      init: function(selector) {
        full = new kendo.View(selector, template);
        full.render();
        navigation.navigating.to("#home", navigating.to);
        navigation.navigating.from("#home", navigating.from);
        elements.cache(full);
        return subscribe(pub);
      },
      before: function() {
        return setTimeout((function() {
          return $.publish("/postman/deliver", [
            {
              paused: false
            }, "/camera/pause"
          ]);
        }), 500);
      },
      show: function(item) {
        if (!paused) {
          return;
        }
        pub.select(item);
        paused = false;
        return full.container.kendoStop(true).kendoAnimate({
          effects: "zoomIn fadeIn",
          show: true,
          complete: function() {
            return $.publish("/bottom/update", ["full"]);
          }
        });
      },
      select: function(item, temp) {
        effectId = item.id;
        if (!temp) {
          full.el.filters.find("li").removeClass("selected").filter("[data-filter-id=" + item.id + "]").addClass("selected");
        }
        return $.publish("/postman/deliver", [effectId, "/camera/effect"]);
      },
      filter: {
        click: function(e) {
          var i;
          i = $(e.target).data("filter-index");
          index.saved = i;
          return index.select(i);
        },
        mouseover: function(e) {
          return index.preview($(e.target).data("filter-index"));
        },
        mouseout: function(e) {
          return index.unpreview();
        }
      },
      photo: function() {
        var callback;
        callback = function() {
          return $.publish("/bottom/update", ["full"]);
        };
        return capture(callback, {
          index: 0,
          count: 1
        });
      },
      paparazzi: function() {
        var callback;
        callback = function() {
          callback = function() {
            callback = function() {
              return $.publish("/bottom/update", ["full"]);
            };
            return setTimeout((function() {
              return capture(callback, {
                index: 2,
                count: 3
              });
            }), 1000);
          };
          return setTimeout((function() {
            return capture(callback, {
              index: 1,
              count: 3
            });
          }), 1000);
        };
        return capture(callback, {
          index: 0,
          count: 3
        });
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/postman/postman',[], function() {
    /*		The Postman!
    
    	The postman is a super simple combination of pub/sub and post message.
    
    	outgoing: the postman simply listens for the /postman/deliver message and dispatches whatever
    	its contents are as the body of the 'message' object. The address is used by the receiver
    	to determine who should respond to the message.
    
    	incoming: the postman listens to the post message event on the window and
    	dispatches the event with the address specified
    */

    var pub;
    return pub = {
      init: function(r) {
        var recipient;
        recipient = r;
        window.onmessage = function(event) {
          return $.publish(event.data.address, [event.data.message]);
        };
        return $.subscribe("/postman/deliver", function(message, address, block) {
          var delivery;
          delivery = {};
          delivery.address = address;
          delivery.message = message;
          return recipient.postMessage(delivery, "*", block);
        });
      }
    };
  });

}).call(this);

define('text!mylibs/gallery/views/thumb.html',[],function () { return '<div class="thumbnail"></div>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/gallery/gallery',['Kendo', 'mylibs/utils/utils', 'mylibs/file/filewrapper', 'text!mylibs/gallery/views/thumb.html'], function(kendo, utils, filewrapper, template) {
    var active, add, animation, arrows, at, clear, columns, container, create, data, dataSource, deselect, destroy, details, ds, el, files, flipping, get, index, keyboard, keys, page, pageSize, pages, pub, render, rows, select, selected, total,
      _this = this;
    columns = 3;
    rows = 3;
    pageSize = columns * rows;
    files = [];
    ds = {};
    data = [];
    container = {};
    el = {};
    selected = {};
    total = 0;
    index = 0;
    flipping = false;
    pages = {
      previous: {},
      next: {}
    };
    active = {};
    details = false;
    keyboard = {};
    animation = {
      effects: "pageturn:horizontal",
      reverse: false,
      duration: 800
    };
    deselect = function() {
      container.find(".thumbnail").removeClass("selected");
      selected = null;
      return $.publish("/top/update", ["deselected"]);
    };
    select = function(name) {
      var item;
      item = container.find("[data-name='" + name + "']");
      selected = item.parent(":first");
      if (selected.hasClass("selected")) {
        keys.unbind();
        return $.publish("/details/show", [get("" + (item.data("name")))]);
      } else {
        container.find(".thumbnail").removeClass("selected");
        selected.addClass("selected");
        $.publish("/item/selected", [get(name)]);
        return $.publish("/top/update", ["selected"]);
      }
    };
    page = function(direction) {
      if (flipping) {
        return;
      }
      arrows.both.hide();
      if (direction > 0 && ds.page() > 1) {
        flipping = true;
        animation.reverse = true;
        ds.page(ds.page() - 1);
        render(true);
      }
      if (direction < 0 && ds.page() < ds.totalPages()) {
        flipping = true;
        animation.reverse = false;
        ds.page(ds.page() + 1);
        return render(true);
      }
    };
    clear = function() {
      pages.previous.empty();
      pages.next.empty();
      return $.publish("/postman/deliver", [{}, "/file/read"]);
    };
    destroy = function() {
      var name,
        _this = this;
      name = selected.children(":first").attr("data-name");
      return selected.kendoStop(true).kendoAnimate({
        effects: "zoomOut fadeOut",
        hide: true,
        complete: function() {
          return filewrapper.deleteFile(name).done(function() {
            $.publish("/top/update", ["deselected"]);
            selected.remove();
            ds.remove(ds.get(name));
            return render();
          });
        }
      });
    };
    get = function(name) {
      var match, position;
      match = ds.get(name);
      index = ds.view().indexOf(match);
      position = ds.page() > 1 ? pageSize * (ds.page() - 1) + index : index;
      return {
        length: ds.data().length,
        index: position,
        item: match
      };
    };
    at = function(newIndex, noPage) {
      var match, position, target;
      index = newIndex;
      target = Math.ceil((index + 1) / pageSize);
      if (target !== ds.page()) {
        if (!noPage) {
          ds.page(target);
          render();
        }
      }
      position = index - pageSize * (target - 1);
      match = {
        length: ds.data().length,
        index: index,
        item: ds.view()[position]
      };
      $.publish("/details/update", [match]);
      return select(match.item.name);
    };
    dataSource = {
      create: function(data) {
        return ds = new kendo.data.DataSource({
          data: data,
          pageSize: pageSize,
          change: function() {
            return deselect();
          },
          sort: {
            dir: "desc",
            field: "name"
          },
          schema: {
            model: {
              id: "name"
            }
          }
        });
      }
    };
    add = function(item) {
      item = {
        name: item.name,
        file: item.file,
        type: item.type
      };
      if (!ds) {
        return ds = dataSource.create([item]);
      } else {
        return ds.add(item);
      }
    };
    create = function(item) {
      var element, fadeIn;
      element = {};
      fadeIn = function(e) {
        return $(e).kendoAnimate({
          effects: "fadeIn",
          show: true
        });
      };
      element = new Image();
      element.onload = fadeIn(element);
      element.src = item.file;
      element.setAttribute("data-name", item.name);
      element.setAttribute("draggable", true);
      element.width = 240;
      element.height = 180;
      element.setAttribute("class", "hidden");
      $(element).kendoMobileClickable({
        click: pub.click
      });
      return element;
    };
    render = function(flip) {
      var complete, item, thumbnail, thumbs, _i, _len, _ref;
      thumbs = [];
      _ref = ds.view();
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        item = _ref[_i];
        thumbnail = new kendo.View(pages.next, template);
        thumbs.push({
          dom: thumbnail.render({}, true),
          data: item
        });
      }
      $("#gallery").css("pointer-events", "none");
      complete = function() {
        var justPaged;
        setTimeout(function() {
          var _j, _len1, _results;
          _results = [];
          for (_j = 0, _len1 = thumbs.length; _j < _len1; _j++) {
            item = thumbs[_j];
            _results.push((function() {
              var element;
              element = create(item.data);
              return item.dom.append(element);
            })());
          }
          return _results;
        }, 50);
        pages.next.show();
        justPaged = pages.previous;
        justPaged.hide();
        justPaged.empty();
        pages.previous = pages.next;
        pages.next = justPaged;
        flipping = false;
        arrows.left.toggle(ds.page() > 1);
        arrows.right.toggle(ds.page() < ds.totalPages());
        $("#gallery").css("pointer-events", "auto");
        if (flip) {
          return setTimeout(function() {
            return at((ds.page() - 1) * pageSize);
          }, 50);
        }
      };
      if (flip) {
        return container.kendoAnimate({
          effects: animation.effects,
          face: animation.reverse ? pages.next : pages.previous,
          back: animation.reverse ? pages.previous : pages.next,
          duration: animation.duration,
          reverse: animation.reverse,
          complete: complete
        });
      } else {
        return complete();
      }
    };
    keys = {
      tokens: [],
      bind: function() {
        this.tokens.push($.subscribe("/keyboard/arrow", function(key) {
          var position;
          position = index % pageSize;
          switch (key) {
            case "left":
              if (index % columns > 0) {
                return at(index - 1, true);
              }
              break;
            case "right":
              if (index % columns < columns - 1) {
                return at(index + 1, true);
              }
              break;
            case "up":
              if (position >= columns) {
                return at(index - columns, true);
              }
              break;
            case "down":
              if (position < (rows - 1) * columns) {
                return at(index + columns, true);
              }
          }
        }));
        this.tokens.push($.subscribe("/keyboard/page", function(dir) {
          if (dir === "down") {
            page(-1);
          }
          if (dir === "up") {
            return page(1);
          }
        }));
        return this.tokens.push($.subscribe("/keyboard/enter", function() {
          return at(index % pageSize);
        }));
      },
      unbind: function() {
        return this.tokens = $.map(this.tokens, function(item) {
          return $.unsubscribe(item);
        });
      }
    };
    arrows = {
      left: null,
      right: null,
      both: null,
      init: function(parent) {
        arrows.left = parent.find(".previous");
        arrows.left.hide();
        arrows.right = parent.find(".next");
        return arrows.both = $([arrows.left[0], arrows.right[0]]);
      }
    };
    return pub = {
      before: function(e) {
        $.publish("/postman/deliver", [
          {
            paused: true
          }, "/camera/pause"
        ]);
        return keys.bind();
      },
      hide: function(e) {
        keys.unbind();
        pages.next.empty();
        return pages.previous.empty();
      },
      show: function(e) {
        return setTimeout(render, 420);
      },
      previous: function(e) {
        return page(1);
      },
      next: function(e) {
        return page(-1);
      },
      swipe: function(e) {
        return page((e.direction === "right") - (e.direction === "left"));
      },
      click: function(e) {
        var thumb;
        thumb = this.element;
        $.publish("/top/update", ["selected"]);
        return select(thumb.data("name"));
      },
      init: function(selector) {
        var page1, page2;
        page1 = new kendo.View(selector, null);
        page2 = new kendo.View(selector, null);
        container = page1.container;
        arrows.init($(selector).parent());
        pages.previous = page1.render().addClass("page gallery");
        active = pages.next = page2.render().addClass("page gallery");
        $.subscribe("/pictures/bulk", function(message) {
          ds = dataSource.create(message.message);
          ds.read();
          if (ds.view().length > 0) {
            return $.publish("/bottom/thumbnail", [ds.view()[0]]);
          }
        });
        $.subscribe("/gallery/details", function(d) {
          return details = d;
        });
        $.subscribe("/gallery/delete", function() {
          return destroy();
        });
        $.subscribe("/gallery/add", function(item) {
          return add(item);
        });
        $.subscribe("/gallery/at", function(index) {
          return at(index);
        });
        $.subscribe("/gallery/clear", function() {
          $.publish("/bottom/thumbnail");
          return filewrapper.clear().done(function() {
            return clear();
          });
        });
        $.subscribe("/gallery/keyboard", function() {
          return keys.bind();
        });
        $.publish("/postman/deliver", [{}, "/file/read"]);
        return gallery;
      }
    };
  });

}).call(this);

define('text!mylibs/gallery/views/details.html',[],function () { return '<section class="details">\n\t\n\t<img data-bind="invisible: isVideo, attr: { src: img.src }" width="720" height="540">\n\n\t<span class="previous" data-bind="visible: previous.visible" data-role="clickable" data-click="APP.details.previous">&lsaquo;</span>\n\t<span class="next" data-bind="visible: next.visible" data-role="clickable" data-click="APP.details.next">&rsaquo;</span>\n\n</section>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/gallery/details',['Kendo', 'mylibs/utils/utils', 'text!mylibs/gallery/views/details.html'], function(kendo, utils, template) {
    var details, hide, index, pub, show, update, viewModel, visible;
    index = 0;
    visible = false;
    details = {};
    viewModel = kendo.observable({
      video: {
        src: function() {
          return utils.placeholder.image();
        }
      },
      img: {
        src: function() {
          return utils.placeholder.image();
        }
      },
      type: "jpeg",
      isVideo: function() {
        return this.get("type") === "webm";
      },
      next: {
        visible: false
      },
      previous: {
        visible: false
      }
    });
    hide = function() {
      $.publish("/top/update", ["gallery"]);
      $.publish("/gallery/keyboard");
      return details.container.kendoStop(true).kendoAnimate({
        effects: "zoomOut",
        hide: true,
        complete: function() {
          return $.unsubscribe("/gallery/delete");
        }
      });
    };
    show = function(message) {
      update(message);
      return details.container.kendoStop(true).kendoAnimate({
        effects: "zoomIn",
        show: true,
        complete: function() {
          $.publish("/top/update", ["details"]);
          return $.subscribe("/gallery/delete", function() {
            return hide();
          });
        }
      });
    };
    update = function(message) {
      viewModel.set("type", message.item.type);
      viewModel.set("img.src", message.item.file);
      viewModel.set("next.visible", message.index < message.length - 1);
      viewModel.set("previous.visible", message.index > 0 && message.length > 1);
      return index = message.index;
    };
    return pub = {
      init: function(selector) {
        var page, that,
          _this = this;
        that = this;
        details = new kendo.View(selector, template);
        details.render(viewModel, true);
        $.subscribe("/details/hide", function() {
          visible = false;
          return hide();
        });
        $.subscribe("/details/show", function(message) {
          visible = true;
          return show(message);
        });
        $.subscribe("/details/update", function(message) {
          return update(message);
        });
        page = function(direction) {
          if (!visible) {
            return;
          }
          if (direction === "left" && viewModel.previous.visible) {
            that.previous();
          }
          if (direction === "right" && viewModel.next.visible) {
            that.next();
          }
          return false;
        };
        $.subscribe("/keyboard/arrow", page, true);
        return $.subscribe("/keyboard/esc", hide);
      },
      next: function(e) {
        return $.publish("/gallery/at", [index + 1]);
      },
      previous: function(e) {
        return $.publish("/gallery/at", [index - 1]);
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/events/events',[], function() {
    var key, pub;
    key = {
      arrows: {
        up: 38,
        down: 40,
        left: 37,
        right: 39
      },
      esc: 27,
      space: ' '.charCodeAt(0),
      enter: 13,
      w: 'W'.charCodeAt(0),
      page: {
        up: 33,
        down: 34
      }
    };
    return pub = {
      init: function() {
        var p;
        p = function(name, key) {
          return $.publish("/keyboard/" + name, [key]);
        };
        return $(document).keydown(function(e) {
          switch (e.which) {
            case key.arrows.left:
              return p("arrow", "left");
            case key.arrows.right:
              return p("arrow", "right");
            case key.arrows.up:
              return p("arrow", "up");
            case key.arrows.down:
              return p("arrow", "down");
            case key.esc:
              return p("esc", "esc");
            case key.space:
              return p("space", {
                ctrlKey: e.ctrlKey || e.metaKey
              });
            case key.w:
              if (e.ctrlKey || e.metaKey) {
                return p("close");
              }
              break;
            case key.enter:
              return p("enter");
            case key.page.up:
              return p("page", "up");
            case key.page.down:
              return p("page", "down");
          }
        });
      }
    };
  });

}).call(this);

define('text!mylibs/about/views/about.html',[],function () { return '<section class="about">\n\t<hgroup class="appInfoHeader">\n\t\t<h1 data-bind="localeText: appName"></h1>\n\t\t<h2>Version 1.0</h2>\n\t</hgroup>\n\t<div>\n\t\t<hgroup>\n\t\t\t<h3 data-bind="localeHtml: about_kendo"></h3>\n\t\t\t<h4 data-bind="localeHtml: about_kendo_license"></h4>\n\t\t\t<h5 data-bind="localeText: about_credits"></h5>\n\t\t</hgroup>\n\t</div>\n\t<button data-role="button" data-click="APP.about.back" data-bind="localeText: back_button" class="button back"></button>\n\t<button data-role="button" data-click="APP.about.clear" data-bind="localeText: clear_gallery_button" class="button"></button>\n</section>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/about/about',['Kendo', 'mylibs/navigation/navigation', 'text!mylibs/about/views/about.html'], function(kendo, navigation, template) {
    var previous, pub, viewModel;
    previous = "#home";
    viewModel = kendo.observable({});
    return pub = {
      before: function() {
        return $.publish("/postman/deliver", [
          {
            paused: true
          }, "/camera/pause"
        ]);
      },
      init: function(selector) {
        var view;
        view = new kendo.View(selector, template);
        view.render(viewModel, true);
        return $.subscribe('/menu/click/chrome-cam-about-menu', function() {
          $.publish("/postman/deliver", [false, "/menu/enable"]);
          previous = window.APP.app.view().id;
          return navigation.navigate(selector);
        });
      },
      back: function() {
        $.publish("/postman/deliver", [true, "/menu/enable"]);
        return navigation.navigate(previous);
      },
      clear: function() {
        return $.publish("/confirm/show", [
          window.APP.localization.clear_gallery_dialog_title, window.APP.localization.clear_gallery_confirmation, function() {
            $.publish("/gallery/clear");
            return navigation.navigate("#home");
          }
        ]);
      }
    };
  });

}).call(this);

define('text!mylibs/confirm/views/confirm.html',[],function () { return '<div>\n\t<p class="message"></p>\n\t<p><a data-click="APP.confirm.ok" class="button km-button"><span data-bind="localeText: ok_button"></span></a></p>\n\t<p><a data-click="APP.confirm.cancel" class="button km-button"><span data-bind="localeText: cancel_button"></span></a></p>\n</div>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/confirm/confirm',['Kendo', 'text!mylibs/confirm/views/confirm.html'], function(kendo, template) {
    var open, pub, view,
      _this = this;
    view = {};
    this.callback = null;
    open = false;
    return pub = {
      yes: function(e) {
        view.data("kendoMobileModalView").close();
        open = false;
        if (_this.callback) {
          return _this.callback();
        }
      },
      no: function(e) {
        open = false;
        return view.data("kendoMobileModalView").close();
      },
      init: function(selector) {
        var esc;
        view = $(selector);
        $.subscribe("/confirm/show", function(title, message, callback) {
          _this.callback = callback;
          view.find(".title").html(title);
          view.find(".message").html(message);
          view.find(".yes").text(window.APP.localization.yesButton);
          view.find(".no").text(window.APP.localization.noButton);
          view.data("kendoMobileModalView").open();
          return open = true;
        });
        esc = function() {
          if (open) {
            pub.no();
            return false;
          }
        };
        return $.subscribe("/keyboard/esc", esc, true);
      }
    };
  });

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  define('mylibs/assets/assets',[], function() {
    /*		Asset Pipline		
    
    	The asset pipeline recieves base 64 encoded images from the extension and exposes them 
    	locally as images. This is because the sandbox treats any local resources as tainted 
    	and won't allow reading them from a canvas as image data
    */

    var assets, pub;
    assets = {};
    return pub = {
      images: assets,
      init: function() {
        $.subscribe("/assets/add", function(message) {
          var img;
          img = new Image;
          img.src = message.message.image;
          return assets[message.message.name] = img;
        });
        return $.publish("/postman/deliver", [{}, "/assets/get"]);
      }
    };
  });

}).call(this);

define('text!mylibs/nocamera/views/nocamera.html',[],function () { return '<section class="about no-camera">\n\t<hgroup class="appInfoHeader">\n\t\t<h1 data-bind="localeText: no_camera_heading"></h1>\n\t\t<h2 data-bind="localeText: no_camera_description"></h2>\n\t</hgroup>\n\t<div>\n\t\t<div data-bind="localeHtml: no_camera_resolution"></div>\n\t</div>\n</section>';});

// Generated by CoffeeScript 1.4.0
(function() {

  define('app',['Kendo', 'mylibs/bar/bottom', 'mylibs/bar/top', 'mylibs/popover/popover', 'mylibs/full/full', 'mylibs/postman/postman', 'mylibs/utils/utils', 'mylibs/gallery/gallery', 'mylibs/gallery/details', 'mylibs/events/events', 'mylibs/file/filewrapper', 'mylibs/about/about', 'mylibs/confirm/confirm', 'mylibs/assets/assets', 'mylibs/navigation/navigation', "text!mylibs/nocamera/views/nocamera.html"], function(kendo, bottom, top, popover, full, postman, utils, gallery, details, events, filewrapper, about, confirm, assets, navigation, nocamera) {
    var pub;
    return pub = {
      init: function() {
        var APP, promises;
        APP = window.APP = {};
        APP.full = full;
        APP.gallery = gallery;
        APP.about = about;
        APP.confirm = confirm;
        APP.bottom = bottom;
        APP.top = top;
        APP.details = details;
        events.init();
        postman.init(window.top);
        assets.init();
        $.subscribe('/camera/unsupported', function() {
          new kendo.View("#no-camera", nocamera).render(kendo.observable({}), true);
          return navigation.navigate("#no-camera");
        });
        $.publish("/postman/deliver", [true, "/menu/enable"]);
        promises = {
          effects: $.Deferred(),
          localization: $.Deferred()
        };
        $.subscribe("/effects/response", function(filters) {
          APP.filters = filters;
          return promises.effects.resolve();
        });
        $.subscribe("/localization/response", function(dict) {
          APP.localization = dict;
          return promises.localization.resolve();
        });
        $.when(promises.effects.promise(), promises.localization.promise()).then(function() {
          var hideSplash;
          bottom.init(".bottom");
          top.init(".top");
          APP.popover = popover.init("#gallery");
          full.init("#capture");
          details.init("#details");
          gallery.init("#thumbnails");
          about.init("#about");
          confirm.init("#confirm");
          full.show(APP.filters[0]);
          $.publish("/postman/deliver", [
            {
              message: ""
            }, "/app/ready"
          ]);
          window.APP.app = new kendo.mobile.Application(document.body, {
            platform: "android"
          });
          hideSplash = function() {
            return $("#splash").kendoAnimate({
              effects: "fade:out",
              duration: 1000,
              hide: true
            });
          };
          setTimeout(hideSplash, 100);
          return $.subscribe("/keyboard/close", function() {
            return $.publish("/postman/deliver", [null, "/window/close"]);
          });
        });
        $.publish("/postman/deliver", [null, "/localization/request"]);
        return $.publish("/postman/deliver", [null, "/effects/request"]);
      }
    };
  });

}).call(this);

/*

	jQuery pub/sub plugin by Peter Higgins (dante@dojotoolkit.org)

	Loosely based on Dojo publish/subscribe API, limited in scope. Rewritten blindly.

	Original is (c) Dojo Foundation 2004-2010. Released under either AFL or new BSD, see:
	http://dojofoundation.org/license for more information.

	Minor tweak by us.

*/

;(function(d){

	// the topic/subscription hash
	var cache = {};

	d.publish = function(/* String */topic, /* Array? */args){
		// summary:
		//		Publish some data on a named topic.
		// topic: String
		//		The channel to publish on
		// args: Array?
		//		The data to publish. Each array item is converted into an ordered
		//		arguments on the subscribed functions.
		//
		// example:
		//		Publish stuff on '/some/topic'. Anything subscribed will be called
		//		with a function signature like: function(a,b,c){ ... }
		//
		//	|		$.publish("/some/topic", ["a","b","c"]);
		if (cache[topic]) {
			cache[topic].forEach(function(fn) {
				return fn.apply(null, args || []);
			});
		}
	};

	d.subscribe = function(/* String */topic, /* Function */callback, /* Boolean? */ first){
		// summary:
		//		Register a callback on a named topic.
		// topic: String
		//		The channel to subscribe to
		// callback: Function
		//		The handler event. Anytime something is $.publish'ed on a
		//		subscribed channel, the callback will be called with the
		//		published array as ordered arguments.
		//
		// returns: Array
		//		A handle which can be used to unsubscribe this particular subscription.
		//
		// example:
		//	|	$.subscribe("/some/topic", function(a, b, c){ /* handle data */ });
		//
		if(!cache[topic]){
			cache[topic] = [];
		}
		if (first) {
			cache[topic].unshift(callback);
		} else {
			cache[topic].push(callback);
		}
		return [topic, callback]; // Array
	};

	d.unsubscribe = function(/* Array */handle){
		// summary:
		//		Disconnect a subscribed function for a topic.
		// handle: Array
		//		The return value from a $.subscribe call.
		// example:
		//	|	var handle = $.subscribe("/something", function(){});
		//	|	$.unsubscribe(handle);

		var t = handle[0];
		cache[t] && d.each(cache[t], function(idx){
			if(this == handle[1]){
				cache[t].splice(idx, 1);
			}
		});
	};

})(jQuery);

define("libs/jquery/pubsub", function(){});

// Generated by CoffeeScript 1.4.0
(function() {

  define('libs/jquery/plugins',['order!libs/jquery/pubsub'], function() {});

}).call(this);

// Generated by CoffeeScript 1.4.0
(function() {

  require.config({
    paths: {
      Kendo: 'libs/kendo/kendo'
    }
  });

  require(['app', 'order!libs/jquery/plugins'], function(app) {
    return app.init();
  });

}).call(this);

define("main", function(){});
